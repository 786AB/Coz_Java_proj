package com.crts.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.crts.entity.StatusEntity;

@Service
public interface StatusService {

	/* ==== Save Status ==== */
	public StatusEntity saveStatus(StatusEntity se);	
	
	/* ==== Get Status ==== */
	public List<StatusEntity> getAllStatus();	
	
	/* ==== Get Latest Status By requestNumber ==== */ 
	public StatusEntity getStatusByRequestNumber(int reqnum);	
	
	/* ==== Get Status BY CREATEbY  ==== */
	public List<StatusEntity> getAllCreateBy(int createby);	
	
	/* ======== Get ALL ARRISED LATEST Request By LOGIN USER ID ======== */
	public List<Object[]> getAllArrisedLastUpdateRequest(int uid);

	
	/* ======== Get ALL ASSIGN LATEST Request By LOGIN USER ID ======== */
	public List<Object[]> getAllAssignLastUpdateRequest(int uid);


}
