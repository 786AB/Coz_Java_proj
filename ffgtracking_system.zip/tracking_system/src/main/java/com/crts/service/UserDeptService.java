package com.crts.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.crts.entity.UserDeptEntity;
import com.crts.entity.UserEntity;


@Service
public interface UserDeptService {

	public void saveUserDeptAccess(List<UserDeptEntity> ude);

	
	public List<Object[]> getAllUserByDeptid(int deptid);
	
	public String IsUserAdmin(int userid);
	
}
