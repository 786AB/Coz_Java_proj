package com.crts.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.UserDeptEntity;
import com.crts.entity.UserEntity;
import com.crts.repo.UserDeptRepo;
import com.crts.service.UserDeptService;

@Service
public class UserDeptServiceImpl implements UserDeptService {

	@Autowired
	private UserDeptRepo userDeptRepo;

	public void saveUserDeptAccess(List<UserDeptEntity> ude) {
		for (UserDeptEntity u1 : ude) {
			this.userDeptRepo.saveAndFlush(u1);
		}		
	}

	public List<Object[]> getAllUserByDeptid(int deptid) {
		return this.userDeptRepo.getAllUserByDeptid(deptid);
	}


	public String IsUserAdmin(int userid) {
		return this.userDeptRepo.IsUserAdmin(userid);
	}
	
	
	

}