package com.crts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crts.entity.RequestEntity;

@Repository
public interface RequestRepo extends JpaRepository<RequestEntity, Integer> {

	/* ======== Get Last Request Code ======== */
	@Query("select max(re.reqcode) from RequestEntity re where re.reqdeptcode = :deptcode")
	public String getLastRequestNumber(@Param("deptcode") String deptcode);

	/* ======== Get Request By Request Code ======== */
	public RequestEntity getByreqcode(String reqcode);

	/* ===== Get All comments By Request Id and user id ===== */
	@Query(value = "SELECT re.request_id,re.request_number,re.request_title,ce.created_date,ce.comments_desc\r\n"
			+ " FROM requests_entity re INNER JOIN status_entity se ON se.request_number = re.request_id \r\n"
			+ " INNER JOIN comments_entity ce ON ce.request_number = re.request_id \r\n"
			+ " WHERE re.created_By = 4 and re.request_number = 'HR000500000' order by ce.created_date;\r\n", nativeQuery = true)
	public List<Object> getAllCommentByReqId(@Param("id") String uid);

}








