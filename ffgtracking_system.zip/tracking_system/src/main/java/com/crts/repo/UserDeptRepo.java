package com.crts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.crts.entity.UserDeptEntity;
import com.crts.entity.UserEntity;

public interface UserDeptRepo extends JpaRepository<UserDeptEntity, Integer> {

	@Query(value = "SELECT ue.user_id,ue.user_first_name,de.user_role FROM user_entity ue inner join user_dept de on ue.user_id = de.user_id where de.Dept_id = :deptid", nativeQuery = true)
	public List<Object[]> getAllUserByDeptid(int deptid);

	

	@Query(value = "SELECT ud.user_role FROM user_dept ud where ud.user_id = :userid", nativeQuery = true)
	public String IsUserAdmin(int userid);

}
