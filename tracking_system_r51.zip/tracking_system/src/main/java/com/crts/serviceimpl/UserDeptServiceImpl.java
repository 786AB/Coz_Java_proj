package com.crts.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.UserDeptEntity;
import com.crts.repo.UserDeptRepo;
import com.crts.service.UserDeptService;

@Service
public class UserDeptServiceImpl implements UserDeptService {

	@Autowired
	private UserDeptRepo userDeptRepo;

	public UserDeptEntity saveUserDeptAccess(List<UserDeptEntity> ude) {
		UserDeptEntity entity= null; 
		for (UserDeptEntity u1 : ude) {
			entity = this.userDeptRepo.saveAndFlush(u1);
		}
		return entity;		
	}

	public List<Object[]> getAllUserByDeptid(int deptid) {
		return this.userDeptRepo.getAllUserByDeptid(deptid);
	}


	public String IsUserAdmin(int userid) {
		return this.userDeptRepo.IsUserAdmin(userid);
	}


	/* ========= No of Sub Department===============*/
	public int noOfDepartment(int uid) {
		return this.userDeptRepo.noOfDepartment(uid);
	}

	/* ========= No of User in Same Department===============*/
	public int noOfUserInDepartmetn(int uid) {
		return this.userDeptRepo.noOfUserInDepartmetn(uid);
	}
	
	
	

}