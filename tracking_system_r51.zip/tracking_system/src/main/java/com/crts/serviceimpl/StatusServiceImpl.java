package com.crts.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.StatusEntity;
import com.crts.repo.StatusRepo;
import com.crts.service.StatusService;

@Service
public class StatusServiceImpl implements StatusService {

	@Autowired
	private StatusRepo statusRepo;

	/* ==== Save Status ==== */
	public StatusEntity saveStatus(StatusEntity se) {
		return this.statusRepo.save(se);
	}

	/* ==== Get Status ==== */
	public List<StatusEntity> getAllStatus() {
		return this.statusRepo.findAll();
	}

	/* ==== Get Latest Status By requestNumber ==== */
	public StatusEntity getStatusByRequestNumber(int reqnum) {
		return this.statusRepo.getStatusByRequestNumber(reqnum);
	}

	@Override
	public List<StatusEntity> getAllCreateBy(int createby) {
		return this.statusRepo.getStatusByReqcreateby(createby);
	}

	/* ======== Get ALL ARRISED LATEST Request By LOGIN USER ID ======== */
	public List<Object[]> getAllArrisedLastUpdateRequest(int uid) {
		return this.statusRepo.getAllArrisedLastUpdateRequest(uid);
	}

	/* ======== Get ALL ASSIGN LATEST Request By LOGIN USER ID ======== */
	public List<Object[]> getAllAssignLastUpdateRequest(int uid) {
		// TODO Auto-generated method stub
		return this.statusRepo.getAllAssignLastUpdateRequest(uid);
	}

	/* ======== Get ALL RISED CLOSED Request By LOGIN USER ID ======== */
	public List<Object[]> getAllArrisedClosedRequest(int uid) {
		return this.statusRepo.getAllArrisedClosedRequest(uid);
	}

}
