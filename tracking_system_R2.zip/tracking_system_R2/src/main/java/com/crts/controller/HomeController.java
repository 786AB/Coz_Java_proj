package com.crts.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.crts.entity.UserEntity;
import com.crts.helper.Message;
import com.crts.service.UserService;

@Controller
@RequestMapping("/")
public class HomeController {

	@Autowired
	private UserService userService;

	@RequestMapping("/")
	public String welcome(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	@RequestMapping("/index")
	public String welcome1(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("title", "Home - Request Tracking System");
		return "home";
	}

	@RequestMapping("/validuserfrom")
	public String validuserfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "User Validation - Request Tracking System");
		return "validuserfrom";
	}

	@RequestMapping("/passwordchaningfrom")
	public String passwordchaningfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "PasswordChanging - Request Tracking System");
		return "passwordchaningfrom";
	}

	/* ===== lOGIN USER BY USER NAME AND PASSWORD ========= */
	@PostMapping("/loginProcess")
	public String checklogin(@Valid UserEntity userEntity, Errors errors, @RequestParam("uName") String username,
			@RequestParam("uPassword") String password, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				return "index";
			} else {
				boolean getuser = this.userService.userValidate(username, password);
				if (getuser == true) {
					return "home";
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
					return "index";
				}
			}

		} catch (Exception e) {
			errors.hasErrors();
			return "index";
		}

	}

	/* ===== VALIDATING USER BY USER NAME FOR CHANGE PASSWORD ========= */
	@PostMapping("/changepwProcess")
	public String validusnm(@Valid UserEntity userEntity, Errors errors, @RequestParam("uName") String username,
			HttpSession session) {
		UserEntity ue = null;
		ue = this.userService.validatingUserNameOrEmailid(username);
		if (ue != null) {
			session.setAttribute("uemail", ue.getuEmail());
			session.setAttribute("ueoldpass", ue.getuPassword());
			return "passwordchaningfrom";
		} else {
			session.setAttribute("message", new Message("Invalid UserId or EmailId!!", "alert-danger"));
			return "validuserfrom";
		}
	}

	/* ===== CHANGING PASSWORD ========= */
	@PostMapping("/updatepwProcess")
	public String changepw(@Valid UserEntity userEntity, Errors errors, @RequestParam("password") String password,
			@RequestParam("olpassword") String oldpassword, HttpSession session) {
		String upw = session.getAttribute("ueoldpass").toString();

		if (upw.equals(oldpassword)) {
			UserEntity ue = new UserEntity();
			String unm = session.getAttribute("uemail").toString();
			ue = this.userService.validatingUserNameOrEmailid(unm);
			ue.setuPassword(password);
			this.userService.updatePassword(ue);
			return "redirect:/";
		} else {
			return "passwordchaningfrom";

		}

	}

}