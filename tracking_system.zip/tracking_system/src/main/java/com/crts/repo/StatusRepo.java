package com.crts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crts.entity.StatusEntity;

@Repository
public interface StatusRepo extends JpaRepository<StatusEntity, Integer> {

	/* ==== Get Latest Status By requestNumber ==== */
	@Query(value = "SELECT * FROM status_entity se where se.request_number = :reqnumber ORDER BY status_id DESC limit 1", nativeQuery = true)
	public StatusEntity getStatusByRequestNumber(@Param("reqnumber") int reqnumber);

	
	
	
	
	/* ==== Get Status By CREATBY ==== */
	@Query(value = "SELECT * FROM status_entity se WHERE se.created_by = :reqcreateby ORDER BY created_date DESC ;", nativeQuery = true)
	public List<StatusEntity> getStatusByReqcreateby(@Param("reqcreateby") int reqcreateby);

	/* ======== Get ALL ARRISED LATEST Request By LOGIN USER ID ======== */
	@Query(value = "SELECT re.request_number,re.request_title, se.status_desc, re.assigned_to, se.created_date, re.severity, re.piority,  DATEDIFF(se.created_date,re.assigned_date),de.department_name,ue.user_first_name\r\n"
			+ "FROM requests_entity re inner join status_entity se on  se.request_number = re.request_id\r\n"
			+ "inner join user_entity ue on ue.user_id = re.assigned_to \r\n"
			+ "inner join dept_entity de on de.dept_code = re.request_dept\r\n"
			+ "where se.status_id in(SELECT max(status_id) FROM requesttrackingsystemdb.status_entity\r\n"
			+ "group by request_number) and re.created_by = :uid and se.status_desc != 'CLOSE REQUEST';", nativeQuery = true)
	public List<Object[]> getAllArrisedLastUpdateRequest(@Param("uid") int uid);

	/* ======== Get ALL ASSIGN LATEST Request By LOGIN USER ID ======== */
	@Query(value = "SELECT re.request_number,re.request_title, se.status_desc, re.assigned_to, se.created_date, re.severity, re.piority,  DATEDIFF(se.created_date,re.assigned_date),de.department_name,ue.user_first_name\r\n"
			+ "FROM requests_entity re inner join status_entity se on  se.request_number = re.request_id\r\n"
			+ "inner join user_entity ue on ue.user_id = re.assigned_to \r\n"
			+ "inner join dept_entity de on de.dept_code = re.request_dept\r\n"
			+ "where se.status_id in(SELECT max(status_id) FROM requesttrackingsystemdb.status_entity\r\n"
			+ "group by request_number) and re.assigned_to = :uid and se.status_desc != 'CLOSE REQUEST' ", nativeQuery = true)
	public List<Object[]> getAllAssignLastUpdateRequest(@Param("uid") int uid);

	/* ======== Get ALL ARRISED CLOSED Request By LOGIN USER ID ======== */
	@Query(value = "SELECT re.request_number,re.request_title, se.status_desc, re.assigned_to, se.created_date, re.severity, re.piority,  DATEDIFF(se.created_date,re.assigned_date),de.department_name,ue.user_first_name\r\n"
			+ "FROM requests_entity re inner join status_entity se on  se.request_number = re.request_id\r\n"
			+ "inner join user_entity ue on ue.user_id = re.assigned_to \r\n"
			+ "inner join dept_entity de on de.dept_code = re.request_dept\r\n"
			+ "where se.status_id in(SELECT max(status_id) FROM requesttrackingsystemdb.status_entity\r\n"
			+ "group by request_number) and re.created_by = :uid and se.status_desc = 'CLOSE REQUEST' ", nativeQuery = true)
	public List<Object[]> getAllArrisedClosedRequest(@Param("uid") int uid);

}
