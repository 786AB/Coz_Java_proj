package com.crts.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crts.entity.RequestEntity;
import com.crts.entity.StatusEntity;
import com.crts.repo.RequestRepo;
import com.crts.service.RequestService;

@Service
public class RequestServiceImpl implements RequestService {

	@Autowired
	private RequestRepo requestRepo;

	/* ======== Generate Request Code ======== */
	public String getLastRequestNumberByDeptId(String deptcode) {
		String newrequnum = null;
		int lstnumber = 0;
		String LstReq = this.requestRepo.getLastRequestNumber(deptcode);
		if (LstReq != null) {
			lstnumber = Integer.parseInt(LstReq.substring(LstReq.length() - 5));
			if (lstnumber >= 0 && lstnumber < 9) {
				lstnumber = lstnumber + 1;
				newrequnum = "0000" + lstnumber;
			} else if (lstnumber >= 9 && lstnumber < 99) {
				lstnumber = lstnumber + 1;
				newrequnum = "000" + lstnumber;
			} else if (lstnumber >= 99 && lstnumber < 999) {
				lstnumber = lstnumber + 1;
				newrequnum = "00" + lstnumber;
			} else if (lstnumber >= 999 && lstnumber < 9999) {
				lstnumber = lstnumber + 1;
				newrequnum = "0" + lstnumber;
			} else if (lstnumber >= 9999 && lstnumber < 99999) {
				lstnumber = lstnumber + 1;
				newrequnum = Integer.toString(lstnumber);
			} else {
				System.out.println("invalid data");
			}
		} else {
			newrequnum = "00000";
		}
		return newrequnum;
	}

	/* ======== Save Request ======== */
	public boolean saveRequest(String reqtitle, String reqdesc, String getNewRequestNum, String reqtodepart,
			int reqtoperson, String reqfstcomment,  int createby) {
		boolean isSaveRequest = false;

		try {

			String reqstatus = "NEW REQUEST";
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			char stuscod = reqstatus.charAt(0);

			List<StatusEntity> selist = new ArrayList<StatusEntity>();
			StatusEntity se = new StatusEntity();
			se.setSescode(stuscod);
			se.setSestdesc(reqstatus);
			se.setReqdate(date);
			se.setReqcreateby(createby);
			selist.add(se);
			RequestEntity re = new RequestEntity();
			re.setReqdeptcode(reqtodepart);
			re.setReqcode(getNewRequestNum);
			re.setReqtitle(reqtitle);
			re.setReqdesc(reqdesc);
			re.setReqassignto(reqtoperson);
			re.setReqassigndate(date);
			re.setReqinicomment(reqfstcomment);
			re.setRecreatedby(createby);
			re.setStatusEntity(selist);
			se.setRequestEntity(re);

			RequestEntity save = this.requestRepo.save(re);

			if (save != null) {
				isSaveRequest = true;
			} else {
				isSaveRequest = false;
			}
			return isSaveRequest;

		} catch (Exception e) {
			return isSaveRequest = false;
		}
	}

	/* ======== Get Request By Request Code ======== */
	public RequestEntity getRequestByReqcode(String rcode) {
		return this.requestRepo.getByreqcode(rcode);
	}

	/* ======== Update Request ======== */
	public RequestEntity updateRequest(RequestEntity re) {
		try {
			System.out.println("23");
			return this.requestRepo.saveAndFlush(re);
		} catch (Exception e) {
			return null;
		}
	}

	/* ===== Get All comments By Request Id and user id ===== */
	public List<Object[]> getAllCommentByReqId(int uid,String reqnum) {

		return this.requestRepo.getAllCommentByReqId(uid,reqnum);
	}



}
