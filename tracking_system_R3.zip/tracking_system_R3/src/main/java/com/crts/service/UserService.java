package com.crts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.UserEntity;
import com.crts.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;

	public boolean userValidate(String userName, String password) {
		boolean getres = false;
		try {
			UserEntity entity = this.userRepo.getUserEntityByUserNameEmialPassword(userName, password);
			if ((userName.equals(entity.getuName()) || userName.equals(entity.getuEmail()))
					&& password.equals(entity.getuPassword())) {
				getres = true;
			} else {
				getres = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getres;
	}

	public UserEntity validatingUserNameOrEmailid(String username) {
		UserEntity userEntity = null;
		try {
			userEntity = this.userRepo.getUserEntityByUserNameEmial(username);
			System.out.println("sd1");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userEntity;
	}

	public UserEntity updatePassword(UserEntity ue) {
		UserEntity userEntity = null;
		try {
			userEntity = this.userRepo.saveAndFlush(ue);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userEntity;
	}

}
