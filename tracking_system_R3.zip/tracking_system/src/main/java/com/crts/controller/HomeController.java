package com.crts.controller;

import java.util.Date;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.crts.entity.DeptEntity;
import com.crts.entity.UserEntity;
import com.crts.helper.Message;
import com.crts.service.DeptService;
import com.crts.service.UserService;

@Controller
@RequestMapping("/")
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private DeptService deptService;

	@RequestMapping("/")
	public String welcome(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	@RequestMapping("/index")
	public String welcome1(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("title", "Home - Request Tracking System");
		return "home";
	}

	@RequestMapping("/updatepassword")
	public String validuserfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Update Password - Request Tracking System");
		return "updatepassword";
	}

	@RequestMapping("/createdepartment")
	public String createdepartment(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Add Department - Request Tracking System");
		return "createdepartment";
	}

	/* ===== lOGIN USER BY USER NAME AND PASSWORD ========= */
	@PostMapping("/loginProcess")
	public String checklogin(@Valid UserEntity userEntity, Errors errors, @RequestParam("uName") String username,
			@RequestParam("uPassword") String password, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				return "index";
			} else {
				boolean getuser = this.userService.userValidate(username, password);
				if (getuser == true) {
					return "home";
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
					return "index";
				}
			}
		} catch (Exception e) {
			errors.hasErrors();
			return "index";
		}
	}

	/* ===== CHANGING PASSWORD ========= */
	@PostMapping("/updatepwProcess")
	public String changepw(@Valid UserEntity userEntity, Errors errors, @RequestParam("uPassword") String password,
			@RequestParam("uName") String username, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				return "updatepassword";
			} else {
				if (password != null) {
					UserEntity ue = new UserEntity();
					ue = this.userService.validatingUserNameOrEmailid(username);
					ue.setuPassword(password);
					this.userService.updatePassword(ue);
					return "redirect:/";
				} else {
					errors.hasErrors();
					session.setAttribute("message", new Message("Invalid Password !!", "alert-danger"));
					return "updatepassword";
				}
			}
		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
			errors.hasErrors();
			return "updatepassword";
		}

	}

	/* ===== Save Department ===== */

	@PostMapping("/savedeptprocess")
	public String savedept(@Valid DeptEntity deptEntity, Errors errors, @RequestParam("decode") String dcode,
			@RequestParam("dename") String dname, @RequestParam("depcode") String dpcode,
			@RequestParam("deiactive") String diact, HttpSession session) {

		try {
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			Boolean b1 = Boolean.valueOf(diact);

			if (errors.hasErrors()) {
				return "createdepartment";
			} else {
				DeptEntity de = new DeptEntity();
				de.setDecode(dcode);
				de.setDename(dname);
				de.setDepcode(dpcode);
				de.setDecdate(date);
				de.setDecreatedby("Team - b");
				de.setDeiactive(b1);
				this.deptService.saveDepartment(de);
				session.setAttribute("message", new Message("Department Save Successfully !!", "alert-success"));
				return "createdepartment";
			}

		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
			errors.hasErrors();
			return "createdepartment";
		}

	}

}
