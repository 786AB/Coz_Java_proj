package com.crts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.DeptEntity;
import com.crts.repo.DeptRepo;

@Service
public class DeptService {

	@Autowired
	private DeptRepo deptRepo;

	public DeptEntity saveDepartment(DeptEntity de) {
		try {
			return this.deptRepo.save(de);
		} catch (Exception e) {
			return null;
		}
	}

}
