import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserModel } from './formdata/formpage/UserModel';

@Injectable({
  providedIn: 'root',
})
export class MainService {
  baseUrl = 'http://localhost:9088/employee/';

  constructor(private _http: HttpClient) {}



  saveAllUserService(users: any[]): Observable<any> {
    const httpHeaders = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
      authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    const httpOptions = {
      headers: httpHeaders,
    };
    console.log(users);
    console.log('Bearer ' + localStorage.getItem('token'));
    return this._http.post(`${this.baseUrl}savealldata`, users,httpOptions);
  }

  getAllUserService():Observable<any> {
    const httpHeaders = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
      authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    const httpOptions = {
      headers: httpHeaders,
    };



    return this._http.get<any>(`${this.baseUrl}getalllist`,httpOptions);
  }

  deleteUserByUserId(id:number):Observable<any>{
    const httpHeaders = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
      authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    const httpOptions = {
      headers: httpHeaders,
    };
    console.log(id);
    return this._http.post(`${this.baseUrl}deleteuser/${id}`,httpOptions);

  }





}
