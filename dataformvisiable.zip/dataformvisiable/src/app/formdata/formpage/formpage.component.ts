import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import {
  FormGroup,
  FormControl,
  FormsModule,
  Validators,
} from '@angular/forms';
import { MainService } from 'src/app/main.service';
import { UserModel } from './UserModel';

@Component({
  selector: 'app-formpage',
  templateUrl: './formpage.component.html',
  styleUrls: ['./formpage.component.css'],
})
export class FormpageComponent implements OnInit {
  allUser: UserModel[] = [];

  userNumber: any;
  userAge: any;

  phoneMask = [
    '(',
    /[1-9]/,
    /\d/,
    ')',
    '-',
    /\d/,
    /\d/,
    /\d/,
    /\d/,
    '-',
    /\d/,
    /\d/,
    /\d/,
    '-',
    /\d/,
    /\d/,
    /\d/,
  ];
  public getAge(): void {
    this.userAge = this.calculateAge(this.createuser.get('uDob')?.value);
    console.log(this.userAge);
    return this.userAge;
  }
  calculateAge(dateString: string | Date) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }
  createuser = new FormGroup({
    id: new FormControl(),
    index: new FormControl(),
    userName: new FormControl(
      '',
      Validators.compose([Validators.required, Validators.minLength(5)])
    ),
    uDob: new FormControl('', Validators.compose([Validators.required])),
    uGender: new FormControl('', Validators.compose([Validators.required])),
    uDesignation: new FormControl(
      '',
      Validators.compose([Validators.required, Validators.minLength(5)])
    ),
    uCompanyName: new FormControl(
      '',
      Validators.compose([Validators.required, Validators.minLength(5)])
    ),
    uEmail: new FormControl(
      '',
      Validators.compose([
        Validators.required,
        Validators.pattern(
          '^[a-zA-Z]{1}[a-zA-Z0-9.-_]*@[a-zA-Z]{1}[a-zA-Z.-]*[a-zA-Z]{1}[.][a-zA-Z]{2,}$'
        ),
      ])
    ),
    uNumber: new FormControl(
      '',
      Validators.compose([Validators.required, Validators.minLength(10)])
    ),
    uAddress: new FormControl('', Validators.compose([Validators.required])),
  });

  constructor(private router: Router, private _service: MainService) {}
  ngOnInit(): void {
    this.getAllDataFromDB();
    console.log(this.allUser);
  }

  errorMessage = {
    userName: [
      { type: 'required', message: 'User Name is required.' },
      { type: 'minLength', message: 'Minimum 5 char required.' },
    ],
    uDob: [{ type: 'required', message: 'Date of Birth is required.' }],
    uGender: [{ type: 'required', message: 'Gender is required.' }],
    uDesignation: [
      { type: 'required', message: 'Designation is required.' },
      { type: 'minLength', message: 'Minimum 5 char required.' },
    ],
    uCompanyName: [
      { type: 'required', message: 'Company Name is required.' },
      { type: 'minLength', message: 'Minimum 5 char required.' },
    ],
    uEmail: [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Please enter a valid email.' },
    ],
    uNumber: [
      { type: 'required', message: 'Phone number is required.' },
      { type: 'minLength', message: 'Minimun 10 char required.' },
    ],
    uAddress: [
      { type: 'required', message: 'Address is required.' },
      { type: 'minLength', message: 'Minimun 10 char required.' },
    ],
  };

  public getAllUser() {
    return this.allUser;
  }

  public selectUser(index: any): void {
    console.log(this.allUser[index]);
    let reqValues = this.allUser[index];
    if (reqValues.id == null) {
      this.createuser.patchValue({
        id: null,
        index: index,
        userName: reqValues.userName,
        uDob: reqValues.uDob,
        uGender: reqValues.uGender,
        uDesignation: reqValues.uDesignation,
        uCompanyName: reqValues.uCompanyName,
        uEmail: reqValues.uEmail,
        uNumber: reqValues.uNumber,
        uAddress: reqValues.uAddress,
      });
    } else {
      this.createuser.patchValue({
        id: reqValues.id,
        index: null,
        userName: reqValues.userName,
        uDob: reqValues.uDob,
        uGender: reqValues.uGender,
        uDesignation: reqValues.uDesignation,
        uCompanyName: reqValues.uCompanyName,
        uEmail: reqValues.uEmail,
        uNumber: reqValues.uNumber,
        uAddress: reqValues.uAddress,
      });
    }
  }

  public deleteUser(user: any): void {
    console.log(user.id);
    if (user.id == null) {
      for (var i = 0; i < this.allUser.length; i++) {
        if (this.allUser[i] === user) {
          this.allUser.splice(i, 1);
        }
        this.getAllDataFromDB();
      }
    } else {
      this._service.deleteUserByUserId(user.id).subscribe(
        (response: any) => {
          console.log(response);
          this.getAllDataFromDB();

        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  public onSubmit(): any {
    console.warn(this.createuser.value);
    if (this.createuser.valid) {
      this.allUser.push(this.createuser.value);
      console.log(this.allUser);
      this.createuser.reset();
    }
  }

  public onEdit(): any {
    console.log(this.createuser.value);
    if (this.createuser.get('index')?.value == null) {
      this.allUser.forEach((row, i) => {
        if (row.id == this.createuser.get('id')?.value) {
          this.allUser[i] = this.createuser.value;
        }
      });
    } else {
      this.allUser[this.createuser.get('index')?.value] = this.createuser.value;
    }
  }

  public saveAllDataToDB(): void {
    this._service.saveAllUserService(this.getAllUser()).subscribe(
      (response: any) => {
        console.log(response);
        this.getAllDataFromDB();
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  public getAllDataFromDB() {
    this.allUser = [];
    this._service.getAllUserService().subscribe(
      (response: any) => {
        this.allUser = response;
      },
      (error: any) => {
        console.log(error);
      }
    );
    console.log(this.allUser);
  }
}
