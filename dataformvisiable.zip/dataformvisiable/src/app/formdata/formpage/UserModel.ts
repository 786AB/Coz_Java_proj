export class UserModel
{

  id:Number=0 ;
  userName: String ="";
  uDob: String  ="";
  uGender: String  ="";
  uDesignation: String  ="";
  uCompanyName: String  ="";
  uEmail: String  ="";
  uNumber: String  ="";
  uAddress: String  ="";

}
