package com.crts.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.crts.entity.DeptEntity;
import com.crts.entity.RequestEntity;
import com.crts.entity.StatusEntity;
import com.crts.entity.UserEntity;

import com.crts.helper.Message;
import com.crts.service.DeptService;
import com.crts.service.RequestService;
import com.crts.service.StatusService;
import com.crts.service.UserService;

@Controller
@RequestMapping("/home")
@CrossOrigin("*")
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private DeptService deptService;

	@Autowired
	private RequestService requestService;

	@Autowired
	private StatusService statusService;

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/")
	public String welcome(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/index")
	public String welcome1(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	/* ===== HOME PAGE ========= */
	@RequestMapping("user/user_dashboard")
	public String home(Model model) {
		List<StatusEntity> allstatus = this.statusService.getAllStatus();
		model.addAttribute("title", "Home - Request Tracking System");
		model.addAttribute("allstatus", allstatus);
		return "user/user_dashboard";
	}

	/* ===== UPDATE PASSWORD PAGE ========= */
	@RequestMapping("user/updatepassword")
	public String validuserfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Update Password - Request Tracking System");
		return "user/updatepassword";
	}

	/* ===== DEPARTMENT PAGE ========= */
	@RequestMapping("user/createdepartment")
	public String createdepartment(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Add Department - Request Tracking System");
		List<String> ParentCodeList = this.deptService.getParentDeptCode();
		model.addAttribute("ParentCodeList", ParentCodeList);

		return "user/createdepartment";
	}

	/* ===== ADDREQUEST PAGE ========= */
	@RequestMapping("user/addrequest")
	public String addrequestpage(@ModelAttribute("requestEntity") RequestEntity requestEntity,
			BindingResult bindingResult, Model model) {
		List<String> ParentCodeList = this.deptService.getParentDeptCode();
		model.addAttribute("ParentCodeList", ParentCodeList);
		model.addAttribute("title", "Add Request - Request Tracking System");
		return "user/addrequest";
	}

	/* ===== lOGIN USER BY USER NAME AND PASSWORD ========= */
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public String checklogin(@Valid UserEntity userEntity, Model model, Errors errors,
			@RequestParam("uName") String username, @RequestParam("uPassword") String password, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				return "index";
			} else {
				boolean isValidUser = this.userService.userValidate(username, password);
				if (isValidUser) {
					model.addAttribute("title", "Home - Request Tracking System");
					return "user/user_dashboard";
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
					return "redirect:index";
				}
			}
		} catch (Exception e) {
			errors.hasErrors();
			return "redirect:index";
		}
	}

	/* ===== CHANGING PASSWORD PROCESS========= */
	@PostMapping("/updatepwProcess")
	public String changepw(@Valid UserEntity userEntity, Errors errors, @RequestParam("uPassword") String password,
			@RequestParam("uName") String username, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				return "user/updatepassword";
			} else {
				if (password != null) {
					UserEntity ue = new UserEntity();
					ue = this.userService.validatingUserNameOrEmailid(username);
					ue.setuPassword(password);
					this.userService.updatePassword(ue);
					return "redirect:user/updatepassword";
				} else {
					errors.hasErrors();
					session.setAttribute("message", new Message("Invalid Password !!", "alert-danger"));
					return "user/updatepassword";
				}
			}
		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
			errors.hasErrors();
			return "user/updatepassword";
		}

	}

	
	/* ===== Save Department PROCESS ===== */
	@PostMapping("/savedeptprocess")
	public String savedept(@Valid DeptEntity deptEntity, Errors errors, @RequestParam("decode") String dcode,
			@RequestParam("dename") String dname, @RequestParam("depcode") String dpcode,
			@RequestParam("deiactive") String diact, HttpSession session) {
		try {
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			Boolean deptstatus = Boolean.valueOf(diact);
			if (errors.hasErrors()) {
				return "user/createdepartment";
			} else {
				DeptEntity de = new DeptEntity();
				de.setDecode(dcode);
				de.setDename(dname);
				de.setDepcode(dpcode);
				de.setDecdate(date);
				de.setDecreatedby("Team - b");
				de.setDeiactive(deptstatus);
				this.deptService.saveDepartment(de);
				session.setAttribute("message", new Message("Department Save Successfully !!", "alert-success"));
				return "redirect:user/createdepartment";
			}

		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
			errors.hasErrors();
			return "user/createdepartment";
		}

	}

	/* ===== Generate New Request ===== */
	@PostMapping("/generaterequest")
	public String saveRequest(@Valid RequestEntity requestEntity, Errors errors,
			@RequestParam("reqtitle") String reqtitle, @RequestParam("reqdesc") String reqdesc,
			@RequestParam("reqdeptcode") String reqtodepart, @RequestParam("reqassignto") String reqtoperson,
			@RequestParam("reqinicomment") String reqfstcomment, @RequestParam("sestdesc") String reqstatus,
			HttpSession session) {

		try {
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			char stuscod = reqstatus.charAt(0);

			if (errors.hasErrors()) {
				return "user/addrequest";
			} else {
				String getNewRequestNum = this.requestService.getLastRequestNumberByDeptId(reqtodepart);

				StatusEntity se = new StatusEntity();
				se.setSescode(stuscod);
				se.setSestdesc(reqstatus);
				se.setReqdate(date);
				se.setReqcreateby("a");
				RequestEntity re = new RequestEntity();
				List<StatusEntity> selist = new ArrayList<StatusEntity>();
				re.setReqdeptcode(reqtodepart);
				re.setReqcode(reqtodepart + getNewRequestNum);
				re.setReqtitle(reqtitle);
				re.setReqdesc(reqdesc);
				re.setReqassignto(reqtoperson);
				re.setReqassigndate(date);
				re.setReqinicomment(reqfstcomment);
				re.setReqcreateby("a");
				selist.add(se);
				re.setStatusEntity(selist);
				se.setRequestEntity(re);
				RequestEntity entity = this.requestService.saveRequest(re);
				if (entity != null) {
					session.setAttribute("message",
							new Message("Request Generate Successfully !! Your Request Refernece No : " + reqtodepart
									+ getNewRequestNum, "alert-success"));
					return "redirect:user/addrequest";
				} else {
					session.setAttribute("message",
							new Message("Request Generate Fail !! Please try Againg ", "alert-danger"));
					return "redirect:user/addrequest";
				}
			}

		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
			errors.hasErrors();
			return "user/addrequest";
		}
	}

}
