package com.crts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crts.entity.DeptEntity;
import com.crts.service.DeptService;
import com.crts.service.RequestService;

@RestController
@RequestMapping("/getdata")
@CrossOrigin("*")
public class DataController {

	@Autowired
	private DeptService deptService;

	/*
	 * @Autowired private RequestService requestService;
	 */
	/*
	 * @GetMapping("/getlastrequestnumber") public String
	 * getLastRequestNumber(@RequestParam("deptcode") String deptcode, Model model)
	 * { System.out.println(deptcode); return
	 * this.requestService.getLastRequestNumberByDeptId(deptcode); }
	 */
	@GetMapping("/getdeptuser")
	public List<DeptEntity> getDeptUserByDeptCode(@RequestParam("deptcode") String deptcode, Model model) {

		return this.deptService.getDeptUser(deptcode);
	}

}
