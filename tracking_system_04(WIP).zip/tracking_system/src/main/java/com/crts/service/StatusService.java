package com.crts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.StatusEntity;
import com.crts.repo.StatusRepo;

@Service
public class StatusService {

	@Autowired
	private StatusRepo statusRepo;

	/* ==== Save Status ==== */
	public StatusEntity saveStatus(StatusEntity se) {
		return this.statusRepo.save(se);
	}
	
	
	/* ==== Get Status ==== */
	public List<StatusEntity> getAllStatus() {
		return this.statusRepo.findAll();
	}
	
	
	

}
