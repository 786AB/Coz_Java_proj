package com.crts.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "status_entity")
public class StatusEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "status_id")
	private int seid;

	@Column(name = "status_code")
	private char sescode;

	
	@NotEmpty(message = "Status Requires !!")
	@Size(min = 4, max = 25, message = "Minimun Length 4 and maximun 25 charactes are Required !!")
	@Column(length = 25, name = "status_desc")
	private String sestdesc;

	@Column(name = "created_date")
	private Date reqdate;

	@Column(length = 25, name = "created_by")
	private String reqcreateby;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "request_number")
	private RequestEntity requestEntity;

	public int getSeid() {
		return seid;
	}

	public void setSeid(int seid) {
		this.seid = seid;
	}

	public char getSescode() {
		return sescode;
	}

	public void setSescode(char sescode) {
		this.sescode = sescode;
	}

	public String getSestdesc() {
		return sestdesc;
	}

	public void setSestdesc(String sestdesc) {
		this.sestdesc = sestdesc;
	}

	public Date getReqdate() {
		return reqdate;
	}

	public void setReqdate(Date reqdate) {
		this.reqdate = reqdate;
	}

	public String getReqcreateby() {
		return reqcreateby;
	}

	public void setReqcreateby(String reqcreateby) {
		this.reqcreateby = reqcreateby;
	}

	public RequestEntity getRequestEntity() {
		return requestEntity;
	}

	public void setRequestEntity(RequestEntity requestEntity) {
		this.requestEntity = requestEntity;
	}

}
