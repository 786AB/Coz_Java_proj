package com.crts.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.crts.entity.UserDeptEntity;

@Service
public interface UserDeptService {

	public UserDeptEntity saveUserDeptAccess(UserDeptEntity ude);

	
	public List<String> getAllUserByDeptid(int deptid);
	
}
