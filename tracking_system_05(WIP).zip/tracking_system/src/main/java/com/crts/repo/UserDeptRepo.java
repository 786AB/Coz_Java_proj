package com.crts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.crts.entity.UserDeptEntity;

public interface UserDeptRepo extends JpaRepository<UserDeptEntity, Integer>{

	
	@Query(value = "SELECT ue.user_first_name FROM user_entity ue inner join user_dept de on ue.user_id = de.user_id where de.Dept_id = :deptid", nativeQuery = true)
	public List<String> getAllUserByDeptid(int deptid);
	
	
}
