package com.crts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crts.entity.StatusEntity;

@Repository
public interface StatusRepo extends JpaRepository<StatusEntity, Integer> {

	
	/* ==== Get Latest Status By requestNumber ==== */ 
	@Query(value = "SELECT * FROM status_entity se where se.request_number = :reqnumber ORDER BY status_id DESC limit 1", nativeQuery = true)
	public StatusEntity getStatusByRequestNumber(@Param("reqnumber") int reqnumber);

	
	/* ==== Get Status By CREATBY ==== */ 
	@Query(value = "SELECT * FROM status_entity se WHERE se.created_by = :reqcreateby ORDER BY created_date DESC ;", nativeQuery = true)
	public List<StatusEntity> getStatusByReqcreateby(@Param("reqcreateby") String reqcreateby);

		
	
	
	
	
	
}
