package com.crts.serviceimpl;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.UserEntity;
import com.crts.repo.UserRepo;
import com.crts.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	/* ===== Validate User By username or email and password ===== */
	public UserEntity userValidate(String userName, String password) {
		UserEntity validuser = null;
		try {
			UserEntity entity = this.userRepo.getUserEntityByUserNameEmailPassword(userName, password);
			if ((userName.equals(entity.getuName()) || userName.equals(entity.getuEmail()))
					&& password.equals(entity.getuPassword())) {
				validuser = entity;
				/*
				 * session.setAttribute("s1", entity);
				 */
			} else {
				validuser = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return validuser;
	}

	/* ===== Validate User By username or email ===== */
	public UserEntity validatingUserNameOrEmailid(String username) {
		UserEntity userEntity = null;
		try {
			userEntity = this.userRepo.getUserEntityByUserNameEmail(username);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userEntity;
	}

	/* ===== Update User Password ===== */
	public boolean updatePassword(UserEntity ue) {
		UserEntity userEntity = null;
		boolean flag = false;
		try {
			userEntity = this.userRepo.saveAndFlush(ue);
			if (userEntity != null) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

	@Override
	public List<UserEntity> getAllUser() {
		return this.userRepo.findAll();
	}


	
	
	public String getEmailIdByFirstName(String username) {
		return this.userRepo.getEmailIdByFirstName(username);
	}

}