package com.crts.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_dept")
public class UserDeptEntity {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_dept_id")
	private int userdeptid;

	
	
	@Column(name = "user_id")
	private int userid;

	@Column(name = "Dept_id")	
	private int deptid;
	
	@Column(name = "created_date")
	private Date createddate;

	@Column(length = 25, name = "created_by")
	private String createdby;

	@Column(name = "is_admin")
	private boolean isadmin;

	@Column(name = "is_user")
	private boolean isuser;

	
	
	
	
	
	
	
	
	public int getUserdeptid() {
		return userdeptid;
	}

	public void setUserdeptid(int userdeptid) {
		this.userdeptid = userdeptid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public Date getCreateddate() {
		return createddate;
	}

	public void setCreateddate(Date createddate) {
		this.createddate = createddate;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public boolean isIsadmin() {
		return isadmin;
	}

	public void setIsadmin(boolean isadmin) {
		this.isadmin = isadmin;
	}

	public boolean isIsuser() {
		return isuser;
	}

	public void setIsuser(boolean isuser) {
		this.isuser = isuser;
	}

	@Override
	public String toString() {
		return "UserDeptEntity [userdeptid=" + userdeptid + ", userid=" + userid + ", deptid=" + deptid
				+ ", createddate=" + createddate + ", createdby=" + createdby + ", isadmin=" + isadmin + ", isuser="
				+ isuser + "]";
	}

	
	
	
	
	
	
	
	
	
	
	
}
