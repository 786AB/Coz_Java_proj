package com.cozentus.practice.task.model;

public class Employee_data {

		public int empNo;
		public String empName;
	}
