package com.cozentus.practice.task.model;

	import java.time.LocalDate;
import java.time.LocalTime;


import org.springframework.stereotype.Component;
	
@Component
	public class Attendance_data {
		public int empNo;
		public LocalDate attDate;
		public LocalTime inTime;
		public LocalTime outTime;
	}

