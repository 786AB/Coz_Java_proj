package com.cozentus.practice.task.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.cozentus.practice.task.log.Log_Writer;

//take list or declare of Emp_data and attd_data

@Component
public class Attd_Data_Store {

	private ArrayList<Employee_data> empList;
	private ArrayList<Attendance_data> attList;
	
//Build a Constructor
	
	public Attd_Data_Store() {
		Log_Writer.wrtieLog("In Constructor of Data Store");
		PopulateEmployees();
	}
	
//Store data in  ed or populated the employee 
	
	private void PopulateEmployees() {
		try {
			Log_Writer.wrtieLog("PopulateEmployees  : IN"); 
			empList = new ArrayList<Employee_data>();
			for (int i = 0; i < 10; i++) {
				Employee_data ed = new Employee_data();
				ed.empNo = 1000 + i;
				ed.empName = "Employee" + i;
				empList.add(ed);
			}
			Log_Writer.wrtieLog("PopulateEmployees  : OUT");
		} catch (Exception e) {
			Log_Writer.wrtieLog("Error in PopulateEmployees: " + e.toString());
		}
	}
	
//
	public Boolean SaveAttendance(int argEmpNo, LocalDate attdate, LocalTime inTime, String inOut) {
		Log_Writer.wrtieLog("SaveAttendance  : IN");
		if (attList == null)
			attList = new ArrayList<Attendance_data>();
		
//Check data exist or not if not then add data into it (attdlist)
		
			if(inOut.equalsIgnoreCase("I")) { //check in or out
			if (attDataExist(argEmpNo, attdate) == -1) { // if data  not present in the list then add data 
				Attendance_data ad = new Attendance_data();
				ad.empNo = argEmpNo;
				ad.attDate = attdate;
				ad.inTime = inTime;
				attList.add(ad);
			}
		}
			
// searching empno (index >= 0) which exist if get it then add out time
			
			else {
			int rowId = attDataExist(argEmpNo, attdate);
			if (rowId >= 0) {
				Attendance_data ad = attList.get(rowId);
				ad.outTime = inTime;
				attList.add(rowId, ad);
			}else {
				Log_Writer.wrtieLog("SaveAttendance  : out without in time." + argEmpNo + ":" + attdate.toString());	 // if unwanted things occurs
			}
		}

		Log_Writer.wrtieLog("SaveAttendance  : OUT");
		return true;
	}
	
//Check data exist
	
	private int attDataExist(int argEmpNo, LocalDate attDate) {
		int rowId = 0;
		for(Attendance_data att : attList) {
			if (att.empNo == argEmpNo && att.attDate == attDate)
				return rowId;
			rowId++;
		}
		return -1;
	}

	public ArrayList<Attendance_data> getempdata(int argEmpN) {		
		Attendance_data ad = new Attendance_data();
			ArrayList<Attendance_data> op = new ArrayList<Attendance_data>();
			for(Attendance_data att : attList) {
						
				
				if (att.empNo == argEmpN){
					ad = new Attendance_data();
					ad.empNo=att.empNo;
					ad.attDate=att.attDate;
					ad.inTime=att.inTime;
					ad.outTime=att.outTime;
					op.add(ad);
					}
			}
			return op;
		}
	}
	

