package com.cozentus.practice.task.controller;

	import java.time.LocalDate;
	import java.time.LocalTime;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cozentus.practice.task.model.Attd_Data_Store;
import com.cozentus.practice.task.model.Attendance_data;

	@Controller
	@RequestMapping("/")
	public class biz {

		Attd_Data_Store ads;

		@Autowired
		public biz(Attd_Data_Store ads) {
			this.ads = ads;
		}

		@GetMapping("/employeedata")  //http://localhost:8080/employeedata?argEmpno=4&argAttDate=1999-04-30&argintime=08:45:56
		public ResponseEntity<Boolean> employeeIn(@RequestParam("argEmpno") int empid,
				@RequestParam("argAttDate") String attDate, @RequestParam("argintime") String inTime) {
		
			LocalDate ld = LocalDate.parse(attDate);
		    LocalTime lt = LocalTime.parse(inTime);
			return new ResponseEntity<Boolean>(ads.SaveAttendance(empid, ld, lt, inTime),HttpStatus.OK);

		}

	
		@GetMapping("/saveAttendance")
		@ResponseBody
		public ResponseEntity<String> saveAttendance(@RequestParam("argEmpNo") int empid,
				@RequestParam("argAttDate") String attDate, @RequestParam("argintime") String inTime,
				@RequestParam("inOut") String IO) {

			LocalDate ld = LocalDate.parse(attDate);
			LocalTime lt = LocalTime.parse(inTime);
			
			System.out.println(IO);
			if (IO.equalsIgnoreCase("I")) {
				if (ads.SaveAttendance(empid, ld, lt, IO)) {
					String s = "EmpId : " + empid + " AttDate : " + attDate + " IN Time :  " + inTime;
					return new ResponseEntity<String>(s, HttpStatus.OK);
				}
			} else if (IO.equalsIgnoreCase("o")) {
				if (ads.SaveAttendance(empid, ld, lt, IO)) {
					String s = "EmpId : " + empid + " AttDate : " + attDate + " Out Time :  " + inTime;
					return new ResponseEntity<String>(s, HttpStatus.OK);
				}
			}
			return new ResponseEntity<String>("Invalid Data", HttpStatus.SERVICE_UNAVAILABLE);
		}
	
	@GetMapping("/showlist")
	@ResponseBody
	public void showemp(@RequestParam("argEmpNo") int empid) {
		ArrayList<Attendance_data> list = ads.getempdata(empid);
		for (Attendance_data ac : list) {
			System.out.println(ac.empNo);
			System.out.println(ac.attDate);
			System.out.println(ac.inTime);
			System.out.println(ac.outTime);
		 new ResponseEntity<String>(ac.empNo +"" + ac.attDate+ac.inTime+ac.outTime, HttpStatus.OK);;
		}
	}
}
