package com.cozentus.practice.task.log;

import java.io.FileWriter;

public class Log_Writer {

	private static String logFileName = "C:\\Users\\USER\\Desktop\\Java\\Practice\\AB.txt";
	
	public static void wrtieLog(String whatToWrite) {
		try {
			FileWriter fw = new FileWriter(logFileName, true);
			fw.write(whatToWrite);
			fw.write("\n");
			fw.close();
		}catch(Exception e) {
			System.out.println("Error creating log file");
		}
	}
}
