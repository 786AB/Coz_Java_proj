package com.crts.service;

import org.springframework.stereotype.Service;

import com.crts.entity.UserEntity;

@Service
public interface UserService {

	public boolean userValidate(String userName, String password);
	
	public UserEntity validatingUserNameOrEmailid(String username);

	public boolean updatePassword(UserEntity ue);

}