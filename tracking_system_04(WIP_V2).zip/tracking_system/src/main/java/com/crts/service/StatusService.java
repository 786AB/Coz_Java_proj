package com.crts.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.crts.entity.StatusEntity;

@Service
public interface StatusService {

	/* ==== Save Status ==== */
	public StatusEntity saveStatus(StatusEntity se);	
	
	/* ==== Get Status ==== */
	public List<StatusEntity> getAllStatus();	
	
	public StatusEntity getStatusByrequestnumber(int reqnum);	
	
	
	

}
