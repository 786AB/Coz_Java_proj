package com.crts.service;

import java.util.List;
import com.crts.entity.DeptEntity;



public interface DeptService {

	public DeptEntity saveDepartment(DeptEntity de);
	public List<String> getParentDeptCode();
	public List<DeptEntity> getDeptUser(String deptcode);

}
