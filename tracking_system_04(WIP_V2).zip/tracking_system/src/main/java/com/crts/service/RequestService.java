package com.crts.service;


import org.springframework.stereotype.Service;
import com.crts.entity.RequestEntity;

@Service
public interface RequestService {

	/* ======== Generate Request Code ======== */
	public String getLastRequestNumberByDeptId(String deptcode);
	
	
	/* ======== Save Request ======== */
	public RequestEntity saveRequest(RequestEntity re);

	
	/* ======== Get Request By Requrest Code ======== */
	public RequestEntity getRequestByReqcode(String rcode);

	/* ======== Update Request ======== */
	public RequestEntity updateRequest(RequestEntity re);

}
