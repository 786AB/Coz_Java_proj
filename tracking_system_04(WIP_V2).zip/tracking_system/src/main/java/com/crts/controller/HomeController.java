package com.crts.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.crts.entity.DeptEntity;
import com.crts.entity.RequestEntity;
import com.crts.entity.StatusEntity;
import com.crts.entity.UserEntity;

import com.crts.helper.Message;
import com.crts.service.DeptService;
import com.crts.service.RequestService;
import com.crts.service.StatusService;
import com.crts.service.UserService;

@Controller
@RequestMapping("/home")
@CrossOrigin("*")
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private DeptService deptService;

	@Autowired
	private RequestService requestService;

	@Autowired
	private StatusService statusService;

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/")
	public String welcome(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/index")
	public String welcomepage(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	/* ===== HOME PAGE ========= */
	@RequestMapping("user/user_dashboard")
	public String home(Model model) {
		List<StatusEntity> allstatus = this.statusService.getAllStatus();
		model.addAttribute("title", "Home - Request Tracking System");
		model.addAttribute("allstatus", allstatus);
		return "user/user_dashboard";
	}

	/* ===== UPDATE PASSWORD PAGE ========= */
	@RequestMapping("user/updatepassword")
	public String validuserfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Update Password - Request Tracking System");
		return "user/updatepassword";
	}

	/* ===== DEPARTMENT PAGE ========= */
	@RequestMapping("user/createdepartment")
	public String createdepartment(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model) {
		model.addAttribute("title", "Add Department - Request Tracking System");
		List<String> ParentCodeList = this.deptService.getParentDeptCode();
		model.addAttribute("ParentCodeList", ParentCodeList);
		return "user/createdepartment";
	}

	/* ===== ADDREQUEST PAGE ========= */
	@RequestMapping("user/addrequest")
	public String addrequestpage(@ModelAttribute("requestEntity") RequestEntity requestEntity,
			BindingResult bindingResult, Model model) {
		List<String> ParentCodeList = this.deptService.getParentDeptCode();
		model.addAttribute("ParentCodeList", ParentCodeList);
		model.addAttribute("title", "Add Request - Request Tracking System");
		return "user/addrequest";
	}

	/* ===== MODIFY REQUEST PAGE ========= */
	@GetMapping("{rcode}/getrequestbycode")
	public String GetRequestByreqcode(@PathVariable("rcode") String rcode,
			@ModelAttribute("requestEntity") RequestEntity requestEntity, BindingResult bindingResult, Model model) {
		RequestEntity getReuestEntity = this.requestService.getRequestByReqcode(rcode);
		model.addAttribute("requestEntity", getReuestEntity);
		List<String> ParentCodeList = this.deptService.getParentDeptCode();
		model.addAttribute("ParentCodeList", ParentCodeList);
		return "user/editrequest";
	}

	/* ===== lOGIN USER BY USER NAME AND PASSWORD PROCESS ========= */
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public String checklogin(@Valid UserEntity userEntity, Model model, Errors errors,
			@RequestParam("uName") String username, @RequestParam("uPassword") String password, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				session.setAttribute("message", new Message("Invalid UserId or Password!!", "alert-danger"));
				return "/";
			} else {
				boolean isValidUser = this.userService.userValidate(username, password);
				if (isValidUser) {
					List<StatusEntity> allstatus = this.statusService.getAllStatus();
					model.addAttribute("title", "Home - Request Tracking System");
					model.addAttribute("allstatus", allstatus);
					return "user/user_dashboard";
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Password!!", "alert-danger"));
					return "/";
				}
			}
		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
			return "/";
		}
	}

	/* ===== CHANGING PASSWORD PROCESS========= */
	@PostMapping("/updatepwProcess")
	public String changepw(@Valid UserEntity userEntity, Errors errors, @RequestParam("uPassword") String password,
			@RequestParam("uName") String username, HttpSession session) {
		try {
			if (errors.hasErrors()) {
				return "user/updatepassword";
			} else {
				if (password != null) {
					UserEntity ue = new UserEntity();
					ue = this.userService.validatingUserNameOrEmailid(username);
					ue.setuPassword(password);
					boolean upPasswordResult = this.userService.updatePassword(ue);
					if (upPasswordResult) {
						session.setAttribute("message", new Message("Password update !!", "alert-success"));
						return "user/updatepassword";
					} else {
						session.setAttribute("message", new Message("Invalid Password !!", "alert-danger"));
						return "user/updatepassword";
					}
				} else {
					errors.hasErrors();
					session.setAttribute("message", new Message("Invalid Password !!", "alert-danger"));
					return "user/updatepassword";
				}
			}
		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
			errors.hasErrors();
			return "user/updatepassword";
		}

	}

	/* ===== Save Department PROCESS ===== */
	@PostMapping("/savedeptprocess")
	public String savedept(@Valid DeptEntity deptEntity, Errors errors, @RequestParam("decode") String dcode,
			@RequestParam("dename") String dname, @RequestParam("depcode") String dpcode,
			@RequestParam("deiactive") String diact, HttpSession session) {
		try {
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			Boolean deptstatus = Boolean.valueOf(diact);
			if (errors.hasErrors()) {
				return "user/createdepartment";
			} else {
				DeptEntity de = new DeptEntity();
				de.setDecode(dcode);
				de.setDename(dname);
				de.setDepcode(dpcode);
				de.setDecdate(date);
				de.setDecreatedby("Team - b");
				de.setDeiactive(deptstatus);
				this.deptService.saveDepartment(de);
				session.setAttribute("message", new Message("Department Save Successfully !!", "alert-success"));
				return "redirect:user/createdepartment";
			}

		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
			errors.hasErrors();
			return "user/createdepartment";
		}

	}

	/* ===== Generate New Request PROCESS ===== */
	@PostMapping("/generaterequest")
	public String saveRequest(@Valid RequestEntity requestEntity, Errors errors,
			@RequestParam("reqtitle") String reqtitle, @RequestParam("reqdesc") String reqdesc,
			@RequestParam("reqdeptcode") String reqtodepart, @RequestParam("reqassignto") String reqtoperson,
			@RequestParam("reqinicomment") String reqfstcomment, @RequestParam("sestdesc") String reqstatus,
			HttpSession session) {

		try {
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			char stuscod = reqstatus.charAt(0);
			System.out.println(stuscod);
			System.out.println(reqstatus);
			if (errors.hasErrors()) {
				return "user/addrequest";
			} else {
				String getNewRequestNum = this.requestService.getLastRequestNumberByDeptId(reqtodepart);

				List<StatusEntity> selist = new ArrayList<StatusEntity>();
				StatusEntity se = new StatusEntity();
				se.setSescode(stuscod);
				se.setSestdesc(reqstatus);
				se.setReqdate(date);
				se.setReqcreateby("a");
				selist.add(se);

				RequestEntity re = new RequestEntity();
				re.setReqdeptcode(reqtodepart);
				re.setReqcode(reqtodepart + getNewRequestNum);
				re.setReqtitle(reqtitle);
				re.setReqdesc(reqdesc);
				re.setReqassignto(reqtoperson);
				re.setReqassigndate(date);
				re.setReqinicomment(reqfstcomment);
				re.setReqcreateby("a");
				re.setStatusEntity(selist);
				se.setRequestEntity(re);
				RequestEntity entity = this.requestService.saveRequest(re);

				if (entity != null) {
					session.setAttribute("message",
							new Message("Request Generate Successfully !! Your Request Refernece No : " + reqtodepart
									+ getNewRequestNum, "alert-success"));
					return "redirect:user/addrequest";
				} else {
					session.setAttribute("message",
							new Message("Request Generate Fail !! Please try Againg ", "alert-danger"));
					return "redirect:user/addrequest";
				}
			}

		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
			errors.hasErrors();
			return "user/addrequest";
		}
	}

	/* ===== MODIFY REQUEST PROCESS========= */
	@PostMapping("/updaterequest")
	public String updateRequest(@Valid RequestEntity requestEntity, Errors errors, @RequestParam("reqid") int reqid,
			@RequestParam("reqcode") String reqcode, @RequestParam("reqtitle") String reqtitle,
			@RequestParam("reqdesc") String reqdesc, @RequestParam("reqdeptcode") String reqtodepart,
			@RequestParam("reqassignto") String reqtoperson, @RequestParam("reqinicomment") String reqfstcomment,
			@RequestParam("sestdesc") String reqstatus, HttpSession session) {
		try {
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			char stuscod = reqstatus.charAt(0);

			if (errors.hasErrors()) {
				return "user/user_dashboard";
			} else {

				StatusEntity se = new StatusEntity();
				se.setSeid(stuscod);
				se.setSescode(stuscod);
				se.setSestdesc(reqstatus);
				se.setReqdate(date);
				se.setReqcreateby("a");

				RequestEntity re = new RequestEntity();
				List<StatusEntity> selist = new ArrayList<StatusEntity>();
				re.setReqid(reqid);
				re.setReqdeptcode(reqtodepart);
				re.setReqcode(reqcode);
				re.setReqtitle(reqtitle);
				re.setReqdesc(reqdesc);
				re.setReqassigndate(date);
				re.setReqassignto(reqtoperson);
				re.setReqinicomment(reqfstcomment);
				re.setReqcreateby("bb");
				selist.add(se);
				re.setStatusEntity(selist);
				se.setRequestEntity(re);
				RequestEntity entity = this.requestService.updateRequest(re);
				if (entity != null) {
					session.setAttribute("message",
							new Message("Request Update Successfully !! Your Request Refernece No : " + reqtodepart,
									"alert-success"));
					return "redirect:user/user_dashboard";
				} else {
					session.setAttribute("message",
							new Message("Request Update Fail !! Please try Againg ", "alert-danger"));
					return "redirect:user/user_dashboard";
				}
			}

		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
			errors.hasErrors();
			return "redirect:{reqcode}/getrequestbycode";
		}

	}

}