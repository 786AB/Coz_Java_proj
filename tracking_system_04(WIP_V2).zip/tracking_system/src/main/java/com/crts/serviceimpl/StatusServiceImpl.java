package com.crts.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.StatusEntity;
import com.crts.repo.StatusRepo;
import com.crts.service.StatusService;

@Service
public class StatusServiceImpl implements StatusService {

	@Autowired
	private StatusRepo statusRepo;

	/* ==== Save Status ==== */
	public StatusEntity saveStatus(StatusEntity se) {
		return this.statusRepo.save(se);
	}
	
	
	/* ==== Get Status ==== */
	public List<StatusEntity> getAllStatus() {
		return this.statusRepo.findAll();
	}
	
	
	public StatusEntity getStatusByrequestnumber(int reqnum)
	{
		return this.statusRepo.getStatusByrequestEntity(reqnum);
	}
	
	
	
	

}
