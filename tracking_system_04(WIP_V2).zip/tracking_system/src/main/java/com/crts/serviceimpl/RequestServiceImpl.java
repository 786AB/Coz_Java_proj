package com.crts.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crts.entity.RequestEntity;
import com.crts.repo.RequestRepo;
import com.crts.service.RequestService;

@Service
public class RequestServiceImpl implements RequestService {

	@Autowired
	private RequestRepo requestRepo;

	/* ======== Generate Request Code ======== */
	public String getLastRequestNumberByDeptId(String deptcode) {
		String newrequnum = null;
		int newnumber = 0;
		String string = this.requestRepo.getLastRequestNumber(deptcode);
		if (string != null) {
			newnumber = Integer.parseInt(string.substring(string.length() - 5));
			if (newnumber >= 0 && newnumber < 9) {
				newnumber = newnumber + 1;
				newrequnum = "0000" + newnumber;
			} else if (newnumber >= 9 && newnumber < 99) {
				newnumber = newnumber + 1;
				newrequnum = "000" + newnumber;
			} else if (newnumber >= 99 && newnumber < 999) {
				newnumber = newnumber + 1;
				newrequnum = "00" + newnumber;
			} else if (newnumber >= 999 && newnumber < 9999) {
				newnumber = newnumber + 1;
				newrequnum = "0" + newnumber;
			} else if (newnumber >= 9999 && newnumber < 99999) {
				newnumber = newnumber + 1;
				newrequnum = Integer.toString(newnumber);
			}

			else {
				System.out.println("invalid data");
			}
			System.out.println(newnumber);
		}

		else {
			newrequnum = "00000";
		}
		System.out.println("This is from reqsserv" + newrequnum);
		return newrequnum;
	}

	/* ======== Save Request ======== */
	public RequestEntity saveRequest(RequestEntity re) {
		try {
			return this.requestRepo.save(re);
		} catch (Exception e) {
			return null;
		}
	}

	/* ======== Get Request By Requrest Code ======== */
	public RequestEntity getRequestByReqcode(String rcode) {
		return this.requestRepo.getByreqcode(rcode);
	}

	/* ======== Update Request ======== */
	public RequestEntity updateRequest(RequestEntity re) {
		try {
			return this.requestRepo.saveAndFlush(re);
		} catch (Exception e) {
			return null;
		}
	}

}
