package com.crts.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crts.entity.DeptEntity;
import com.crts.repo.DeptRepo;
import com.crts.service.DeptService;

@Service
public class DeptServiceImpl implements DeptService {

	@Autowired
	private DeptRepo deptRepo;

	public DeptEntity saveDepartment(DeptEntity de) {
		try {
			return this.deptRepo.save(de);
		} catch (Exception e) {
			return null;
		}
	}

	public List<String> getParentDeptCode() {
		return this.deptRepo.getAllDeptEntityParentCode();
	}

	public List<DeptEntity> getDeptUser(String deptcode) {
		return this.deptRepo.getAllDeptEntityUser(deptcode);
	}

}
