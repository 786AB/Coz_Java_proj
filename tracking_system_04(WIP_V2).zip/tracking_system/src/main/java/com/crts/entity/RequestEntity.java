package com.crts.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.CascadeType;

@Entity
@Table(name = "requests_entity")
public class RequestEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_id")
	private int reqid;

	@NotEmpty(message = "Department Code Required !!")
	@Size(min = 4, max = 6, message = "Department Most Have Minimun Length 4 and maximun 6 charactes are Required !!")
	@Column(length = 25, name = "request_dept")
	private String reqdeptcode;

	
	@Column(length = 25, name = "request_number")
	private String reqcode;

	@NotEmpty(message = "Request Title Can't Empty!!")
	@Size(min = 4, max = 25, message = "Minimun Length 4 and maximun 25 charactes are Required !!")
	@Column(length = 25, name = "request_title")
	private String reqtitle;

	@NotEmpty(message = "Request Description Can't Empty!!")
	@Size(min = 10, max = 190, message = "Minimun Length 10 and maximun 190 charactes are Required !!")
	@Column(length = 200, name = "request_description")
	private String reqdesc;

	@NotEmpty(message = "Request Assign Person Can't Empty!!")
	@Size(min = 4, max = 25, message = " Assign Person Must Have Minimun Length 4 and maximun 25 charactes are Required !!")
	@Column(length = 25, name = "assigned_to")
	private String reqassignto;

	@Column(name = "assigned_date")
	private Date reqassigndate;

	@NotEmpty(message = "Initial Comment Can't Empty!!")
	@Size(min = 10, max = 250, message = "Minimun Length 10 and maximun 250 charactes are Required !!")
	@Column(length = 255, name = "initial_comments")
	private String reqinicomment;

	@Column(length = 25, name = "created_by")
	private String reqcreateby;

	@OneToMany(mappedBy = "requestEntity", cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<StatusEntity> statusEntity;

	public int getReqid() {
		return reqid;
	}

	public void setReqid(int reqid) {
		this.reqid = reqid;
	}

	public String getReqdeptcode() {
		return reqdeptcode;
	}

	public void setReqdeptcode(String reqdeptcode) {
		this.reqdeptcode = reqdeptcode;
	}

	public String getReqcode() {
		return reqcode;
	}

	public void setReqcode(String reqcode) {
		this.reqcode = reqcode;
	}

	public String getReqtitle() {
		return reqtitle;
	}

	public void setReqtitle(String reqtitle) {
		this.reqtitle = reqtitle;
	}

	public String getReqdesc() {
		return reqdesc;
	}

	public void setReqdesc(String reqdesc) {
		this.reqdesc = reqdesc;
	}

	public String getReqassignto() {
		return reqassignto;
	}

	public void setReqassignto(String reqassignto) {
		this.reqassignto = reqassignto;
	}

	public Date getReqassigndate() {
		return reqassigndate;
	}

	public void setReqassigndate(Date reqassigndate) {
		this.reqassigndate = reqassigndate;
	}

	public String getReqinicomment() {
		return reqinicomment;
	}

	public void setReqinicomment(String reqinicomment) {
		this.reqinicomment = reqinicomment;
	}

	public String getReqcreateby() {
		return reqcreateby;
	}

	public void setReqcreateby(String reqcreateby) {
		this.reqcreateby = reqcreateby;
	}

	public List<StatusEntity> getStatusEntity() {
		return statusEntity;
	}

	public void setStatusEntity(List<StatusEntity> statusEntity) {
		this.statusEntity = statusEntity;
	}

	@Override
	public String toString() {
		return "RequestEntity [reqid=" + reqid + ", reqdeptcode=" + reqdeptcode + ", reqcode=" + reqcode + ", reqtitle="
				+ reqtitle + ", reqdesc=" + reqdesc + ", reqassignto=" + reqassignto + ", reqassigndate="
				+ reqassigndate + ", reqinicomment=" + reqinicomment + ", reqcreateby=" + reqcreateby
				+ ", statusEntity=" + statusEntity + "]";
	}
	
	
	
	

}