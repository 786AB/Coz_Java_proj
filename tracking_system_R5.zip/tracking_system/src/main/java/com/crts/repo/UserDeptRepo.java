package com.crts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.crts.entity.UserDeptEntity;
import com.crts.entity.UserEntity;

public interface UserDeptRepo extends JpaRepository<UserDeptEntity, Integer> {

	@Query(value = "SELECT ue.user_id,ue.user_first_name,de.user_role FROM user_entity ue inner join user_dept de on ue.user_id = de.user_id where de.Dept_id = :deptid", nativeQuery = true)
	public List<Object[]> getAllUserByDeptid(int deptid);

	

	@Query(value = "SELECT ud.user_role FROM user_dept ud where ud.user_id = :userid", nativeQuery = true)
	public String IsUserAdmin(int userid);


	/* ========= No of Sub Department===============*/
	@Query(value = "SELECT count(Dept_id) FROM dept_entity\r\n"
			+ "where parent_department_code = (SELECT parent_department_code FROM dept_entity\r\n"
			+ "where Dept_id = (SELECT Dept_id FROM user_dept\r\n"
			+ "where user_id = :uid and user_role != 'nouser' ));", nativeQuery = true)
	public int noOfDepartment (@Param("uid") int uid);
	
	
	
	/* ========= No of User in Same Department===============*/
	@Query(value = "SELECT count(user_dept_id) FROM requesttrackingsystemdb.user_dept\r\n"
			+ "where Dept_id = (SELECT Dept_id FROM requesttrackingsystemdb.user_dept\r\n"
			+ "where user_id = :uid) and user_role != 'nouser';\r\n"
			+ "", nativeQuery = true)	
	public int noOfUserInDepartmetn(@Param("uid") int uid);
	
	
	
	
}
