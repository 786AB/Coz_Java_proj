package com.crts.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.crts.entity.CommentsEntity;
import com.crts.entity.CommentsHistory;
import com.crts.entity.DeptEntity;
import com.crts.entity.MailResponse;
import com.crts.entity.RequestEntity;
import com.crts.entity.StatusEntity;
import com.crts.entity.UserDeptEntity;
import com.crts.entity.UserEntity;
import com.crts.helper.Message;
import com.crts.service.CommentsService;
import com.crts.service.DeptService;
import com.crts.service.RequestService;
import com.crts.service.StatusService;
import com.crts.service.UserDeptService;
import com.crts.service.UserService;
import com.crts.serviceimpl.EmailService;

@Controller
@RequestMapping("/home")
@CrossOrigin("*")
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private DeptService deptService;

	@Autowired
	private RequestService requestService;

	@Autowired
	private StatusService statusService;

	@Autowired
	private EmailService service;

	@Autowired
	private UserDeptService userDeptService;

	@Autowired
	private CommentsService commentsService;

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/")
	public String welcome(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult, Model model,
			HttpSession session, HttpServletResponse response) {
		session.invalidate();
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		System.out.println("32");
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/index")
	public String welcomepage(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		System.out.println("334");
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		session.invalidate();
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		session.setAttribute("message", new Message("Successfully Logout!!", "alert-danger"));
		session.invalidate();
		return "redirect:/home/index";
	}

	/* ===== HOME PAGE ========= */
	@RequestMapping("user/dashboard")
	public String dashboard(Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Home - Request Tracking System");

			int noOfDepartment = this.userDeptService.noOfDepartment((int) session.getAttribute("uid"));
			int noOfUserInDepartmetn = this.userDeptService.noOfUserInDepartmetn((int) session.getAttribute("uid"));
			model.addAttribute("noofdept", noOfDepartment);
			model.addAttribute("noofuser", noOfUserInDepartmetn);

			return "user/dashboardpage";
		}
	}

	/* ===== view_user request PAGE ========= */
	@RequestMapping("user/viewrequest")
	public String viewallreq(Model model, HttpSession session, HttpServletResponse response) {

		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println("============000000000000000");

			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			
			
			System.out.println("============111111111111111111");
			
			List<Object[]> allstatus1 = this.statusService
					.getAllArrisedLastUpdateRequest((int) session.getAttribute("uid"));
			List<StatusEntity> allarrisestatus = new ArrayList<StatusEntity>();
			System.out.println(allstatus1);
			
			
			for (Object[] obj1 : allstatus1) {
				String reqcode = (String) obj1[0];
				String reqtitle = ((String) obj1[1]);
				String status_desc = ((String) obj1[2]);
				int reqassignto = (int) (obj1[3]);
				Date date = (Date) obj1[4];
				BigInteger  age21 = (BigInteger) obj1[5];
		        int age = age21.intValue();		        
				RequestEntity re1 = new RequestEntity();
				re1.setReqassignto(reqassignto);
				re1.setReqtitle(reqtitle);
				re1.setReqcode(reqcode);
				re1.setRecreatedby(age);

				StatusEntity ue1 = new StatusEntity(status_desc, date, re1);
				allarrisestatus.add(ue1);
			}
			
			
			
			List<Object[]> allstatus2 = this.statusService
					.getAllAssignLastUpdateRequest((int) session.getAttribute("uid"));
			List<StatusEntity> allassignstatus = new ArrayList<StatusEntity>();
	
			System.out.println(allstatus2);
			for (Object[] obj2 : allstatus2) {
				String reqcode = (String) obj2[0];
				String reqtitle = ((String) obj2[1]);
				String status_desc = ((String) obj2[2]);
				int reqassignto = (int) (obj2[3]);
				Date date = (Date) obj2[4];
				BigInteger  age22 = (BigInteger) obj2[5];				  
		        int age = age22.intValue();
				RequestEntity re2 = new RequestEntity();
				re2.setReqassignto(reqassignto);
				re2.setReqtitle(reqtitle);
				re2.setReqcode(reqcode);
				re2.setRecreatedby(age);
				StatusEntity ue2 = new StatusEntity(status_desc, date, re2);
				allassignstatus.add(ue2);
			}

			List<Object[]> allstatus3 = this.statusService
					.getAllArrisedClosedRequest((int) session.getAttribute("uid"));

			List<StatusEntity> allarriseclosedstatus = new ArrayList<StatusEntity>();
			System.out.println(allstatus3);
			for (Object[] obj3 : allstatus3) {
				String reqcode = (String) obj3[0];
				String reqtitle = ((String) obj3[1]);
				String status_desc = ((String) obj3[2]);
				int reqassignto = (int) (obj3[3]);
				Date date = (Date) obj3[4];
				BigInteger  age23 = (BigInteger) obj3[5];
		        int age = age23.intValue();
				RequestEntity re3 = new RequestEntity();
				re3.setReqassignto(reqassignto);
				re3.setReqtitle(reqtitle);
				re3.setReqcode(reqcode);
				re3.setRecreatedby(age);
				StatusEntity ue3 = new StatusEntity(status_desc, date, re3);
				allarriseclosedstatus.add(ue3);
				System.out.println(ue3);
			}

			model.addAttribute("title", "Home - Request Tracking System");
			model.addAttribute("allassignstatus", allassignstatus);
			model.addAttribute("allarrisestatus", allarrisestatus);
			model.addAttribute("allarriseclosedstatus", allarriseclosedstatus);

			return "user/view_userrequest";
		}
	}

	/* ===== UPDATE PASSWORD PAGE ========= */
	@RequestMapping("user/updatepassword")
	public String validuserfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Update Password - Request Tracking System");
			return "user/updatepassword";
		}
	}

	/* ===== Reset PASSWORD PAGE ========= */
	@RequestMapping("user/mypassword")
	public String updtLoginUserPswd(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Reset Password - Request Tracking System");
			return "user/resetpassword";
		}
	}

	/* ===== ADD DEPARTMENT PAGE ========= */
	@RequestMapping("user/createdepartment")
	public String createdepartment(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Add Department - Request Tracking System");
			if (session.getAttribute("isUserAdmin").equals("admin") ) {
				System.out.println("sssssssssss");
				List<String> ParentCodeList = this.deptService
						.getAllParentDeptCodeAndUid((int) session.getAttribute("uid"));
				model.addAttribute("ParentCodeList", ParentCodeList);
			} else {
				System.out.println("xxxxxxxxxxxxxx");

				List<String> ParentCodeList = this.deptService.getAllParentDeptCode();
				model.addAttribute("ParentCodeList", ParentCodeList);
			}
System.out.println("========================");
			System.out.println(session.getAttribute("isUserAdmin"));

			return "user/createdepartment";
		}
	}

	/* ===== ADD REQUEST PAGE ========= */
	@RequestMapping("user/createrequest")
	public String addrequestpage(@ModelAttribute("requestEntity") RequestEntity requestEntity,
			BindingResult bindingResult, Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			List<String> deptCodeList = this.deptService.getAllDeptCode();
			model.addAttribute("deptCodeList", deptCodeList);
			model.addAttribute("title", "Add Request - Request Tracking System");
			return "user/createrequest";
		}
	}

	/* ===== MODIFY REQUEST PAGE ========= */
	@GetMapping("{rcode}/getrequestbycode")
	public String GetRequestByreqcode(@PathVariable("rcode") String rcode,
			@ModelAttribute("requestEntity") RequestEntity requestEntity, BindingResult bindingResult, Model model,
			HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			RequestEntity getReuestEntity = this.requestService.getRequestByReqcode(rcode);
			model.addAttribute("requestEntity", getReuestEntity);
			session.setAttribute("assigndate", getReuestEntity.getReqassigndate());
			System.out.println(session.getAttribute("uid"));
			
			List<String> deptCodeList = this.deptService.getAllDeptCode();
			model.addAttribute("deptCodeList", deptCodeList);

			List<Object[]> listaa = this.requestService.getAllCommentByReqId((int) session.getAttribute("uid"), rcode);
			List<CommentsHistory> allCommentHistory = new ArrayList<CommentsHistory>();
			for (Object[] obj101 : listaa) {
				String reqtitle = (String) obj101[0];
				String firstname = ((String) obj101[1]);

				String comdesc = (String) (obj101[2]);

				CommentsHistory che = new CommentsHistory();
				che.setRequesttitle(reqtitle);
				che.setUserfirstname(firstname);
				che.setCommentsdesc(comdesc);
				System.out.println(che);
				allCommentHistory.add(che);
			}

			model.addAttribute("allCommentHistory", allCommentHistory);

			return "user/editrequest";
		}
	}

	/* ===== Add New Comment REQUEST Comment PAGE ========= */
	@GetMapping("{rcode}/getrequestbycodeforcomment")
	public String GetRequestByReqCodeForComment(@PathVariable("rcode") String rcode,
			@ModelAttribute("requestEntity") RequestEntity requestEntity, BindingResult bindingResult, Model model,
			HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			System.out.println("get code ->>>>>>   " + rcode);
			RequestEntity getReuestEntity = this.requestService.getRequestByReqcode(rcode);
			model.addAttribute("requestEntity", getReuestEntity);
			String reqinicomment1 = getReuestEntity.getReqinicomment();
			session.setAttribute("reqinicomment1", reqinicomment1);
			System.out.println(session.getAttribute("reqinicomment1"));
			List<String> deptCodeList = this.deptService.getAllDeptCode();
			model.addAttribute("deptCodeList", deptCodeList);
			return "user/commentrequest";
		}
	}

	/* ===== VIEW ALL DEPARTMENT PAGE ========= */
	@GetMapping("user/getalldepartmentlist")
	public String GetAllDepartment(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			List<DeptEntity> allDept = this.deptService.getAllDept();
			model.addAttribute("allDept", allDept);
			return "user/view_alldepartment";
		}
	}

	/* ===== NEW USER PAGE ========= */
	@RequestMapping("user/createuser")
	public String createuser(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Add User - Request Tracking System");
			return "user/createuser";
		}
	}

	/* ===== MODIFY USER PAGE ========= */
	@GetMapping("{uname}/getuserbyuname")
	public String GetUserByUname(@PathVariable("uname") String uname,
			@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult, Model model,
			HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			UserEntity user = this.userService.validatingUserNameOrEmailid(uname);
			model.addAttribute("title", "Edit User - Request Tracking System");
			model.addAttribute("userEntity", user);
			session.setAttribute("userId", user.getuId());
			session.setAttribute("userfullname", user.getuFName() + " " + user.getuLName());
			System.out.println(user.getuPassword());
			return "user/edituser";
		}
	}

	/* ===== Get ALL USER VIEW PAGE ========= */
	@RequestMapping("user/getalluser")
	public String viewalluser(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			List<UserEntity> alluser = this.userService.getAllUser();
			model.addAttribute("title", "Home - Request Tracking System");
			model.addAttribute("alluser", alluser);
			return "user/view_userall";
		}
	}

	/* ===== USER ACCESS PAGE ========= */
	@GetMapping("user/getuseraccess")
	public String GetUserDeptAccess(@ModelAttribute("userDeptEntity") UserDeptEntity userDeptEntity,
			BindingResult bindingResult, Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {

			List<DeptEntity> deptCodeList = this.deptService.getAllDept();
			model.addAttribute("deptCodeList", deptCodeList);

			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);

			session.setAttribute("curdate", date);
			System.out.println(date);

			System.out.println(session.getAttribute("userId"));
			return "user/user_dept_access";
		}
	}

	/* ===== MY PROFILE PAGE ========= */
	@RequestMapping("user/myprofile")
	public String myprofilepage(Model model, HttpSession session, HttpServletResponse response) {
		model.addAttribute("title", "My Profile - Request Tracking System");
		System.out.println(session.getAttribute("isValidUser"));
		model.addAttribute("title", "My Profile - Request Tracking System");
		model.addAttribute("ue", session.getAttribute("isValidUser"));
		return "user/myprofile";
	}

	/*
	 * =============================================================================
	 * ======================================================
	 */

	/* ===== lOGIN USER BY USER NAME AND PASSWORD PROCESS ========= */
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public String checklogin(@Valid UserEntity userEntity, BindingResult bindingResult, Model model, Errors errors,
			@RequestParam("uName") String username, @RequestParam("uPassword") String password, HttpSession session,
			HttpServletResponse response) {
		try {
			if (errors.hasErrors()) {
				session.setAttribute("message", new Message("Invalid UserId or Password!!", "alert-danger"));
				return "/index";
			} else {
				UserEntity isValidUser = this.userService.userValidate(username, password);
				if (isValidUser != null) {
					session.setAttribute("isValidUser", isValidUser);
					session.setAttribute("username", isValidUser.getuFName());
					session.setAttribute("uid", isValidUser.getuId());
					System.out.println(session.getAttribute("uid"));

					String isUserAdmin = this.userDeptService.IsUserAdmin(isValidUser.getuId());
					session.setAttribute("isUserAdmin", isUserAdmin);
					System.out.println(isUserAdmin);
					return "redirect:/home/user/dashboard";
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Password!!", "alert-danger"));

					return "/index";
				}
			}
		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));

			return "/index";
		}
	}

	/* ===== CHANGING PASSWORD PROCESS========= */
	@PostMapping("/updatepwProcess")
	public String changepw(@Valid UserEntity userEntity, BindingResult bindingResult, Errors errors,
			@RequestParam("uPassword") String password, @RequestParam("uName") String username, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				if (errors.hasErrors()) {
					return "user/updatepassword";
				} else {
					UserEntity ue = new UserEntity();
					ue = this.userService.validatingUserNameOrEmailid(username);
					if (ue != null) {
						ue.setuPassword(password);
						boolean isPasswordUpdate = this.userService.updatePassword(ue);
						if (isPasswordUpdate) {
							session.setAttribute("message", new Message("Password update !!", "alert-success"));
							return "user/updatepassword";
						} else {
							session.setAttribute("message", new Message("Invalid Email Address !!", "alert-danger"));
							return "user/updatepassword";
						}
					} else {
						errors.hasErrors();
						session.setAttribute("message", new Message("Invalid Password !!", "alert-danger"));
						return "user/updatepassword";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
				errors.hasErrors();
				return "user/updatepassword";
			}
		}
	}

	/* ===== RESET PASSWORD PROCESS========= */
	@PostMapping("/resetpasswordprocess")
	public String resetpw(@RequestParam("uName") String username, HttpSession session, HttpServletResponse response) {
		System.out.println("=============-1-1-1-1-1===============");

		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println("=============0000===============");

			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				UserEntity ue = new UserEntity();
				ue = this.userService.validatingUserNameOrEmailid(username);
				if (ue != null) {
					System.out.println("=============33333===============");
					String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
					String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
					String specialCharacters = "!@#$";
					String numbers = "1234567890";
					String combinedChars = capitalCaseLetters + lowerCaseLetters + specialCharacters + numbers;
					Random random = new Random();
					char[] password = new char[8];

					password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
					password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
					password[2] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
					password[3] = numbers.charAt(random.nextInt(numbers.length()));

					for (int i = 4; i < 8; i++) {
						password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
					}
					String newPassword = String.valueOf(password);
					ue.setuPassword(newPassword);
					boolean isPasswordUpdate = this.userService.updatePassword(ue);
					if (isPasswordUpdate) {

						Map<String, Object> model = new HashMap<>();
						model.put("Requestby", "Admin");
						model.put("reqtitle", "Your password is reset");
						model.put("reqmessage", newPassword);
						MailResponse emailw = service.sendResetPasswordEmail(ue.getuEmail(), model);
						System.out.println(emailw);
						System.out.println(ue.getuEmail());
						System.out.println("------------------------->");
						session.setAttribute("message",
								new Message(
										"Password reset !! New Password has been sent to the provided Email Address",
										"alert-success"));
						return "redirect:/home/user/mypassword";
					} else {
						session.setAttribute("message", new Message("Password not update !!", "alert-danger"));
						return "user/mypassword";
					}
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Email !!", "alert-danger"));
					return "user/mypassword";
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid UserId or Email !!", "alert-danger"));
				return "user/mypassword";
			}
		}

	}

	/* ===== Save Department PROCESS ===== */
	@PostMapping("/savedeptprocess")
	public String savedept(@Valid DeptEntity deptEntity, Errors errors, @RequestParam("decode") String dcode,
			@RequestParam("dename") String dname, @RequestParam("depcode") String dpcode,
			@RequestParam("deisactive") String diact, HttpSession session, HttpServletResponse response) {

		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				int createby = (int) session.getAttribute("uid");
				if (errors.hasErrors()) {
					return "user/createdepartment";
				} else {
					boolean isDepartmentSave = this.deptService.saveDepartment(dcode, dname, dpcode, createby, diact);
					if (isDepartmentSave) {
						session.setAttribute("message",
								new Message("Department Save Successfully !!", "alert-success"));
						return "redirect:user/createdepartment";
					} else {
						session.setAttribute("message",
								new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
						return "redirect:user/createdepartment";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				System.out.println("ssdsd1");
				errors.hasErrors();
				return "user/createdepartment";
			}
		}
	}

	/* ===== Generate New Request PROCESS ===== */
	@PostMapping("/generaterequest")
	public String saveRequest(@Valid RequestEntity requestEntity, Errors errors,
			@RequestParam("reqtitle") String reqtitle, @RequestParam("reqdesc") String reqdesc,
			@RequestParam("reqdeptcode") String reqtodepart, @RequestParam("reqassignto") int reqtoperson,
			@RequestParam("reqinicomment") String reqfstcomment, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				if (errors.hasErrors()) {
					return "user/createrequest";
				} else {

					int createby = (int) session.getAttribute("uid");
					String getNewRequestNum1 = this.requestService.getLastRequestNumberByDeptId(reqtodepart);
					String getNewRequestNum = reqtodepart + getNewRequestNum1;

					boolean isRequestSave = this.requestService.saveRequest(reqtitle, reqdesc, getNewRequestNum,
							reqtodepart, reqtoperson, reqfstcomment, createby);
					if (isRequestSave) {
						session.setAttribute("message", new Message(
								"Request Generate Successfully !! Your Request Refernece No : " + getNewRequestNum,
								"alert-success"));
						UserEntity uedata = this.userService.getById(reqtoperson);
						String RequestPersonEmailId = uedata.getuEmail();
						Map<String, Object> model = new HashMap<>();
						model.put("Requestby", "Admin");
						model.put("reqno", getNewRequestNum);
						model.put("reqtitle", reqtitle);
						model.put("reqmessage", reqdesc);
						System.out.println(RequestPersonEmailId);
						service.sendRequestEmail(RequestPersonEmailId, model);

						return "redirect:user/createrequest";
					} else {
						session.setAttribute("message",
								new Message("Request Generate Fail !! Please try Againg in else ", "alert-danger"));
						return "redirect:user/createrequest";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message",
						new Message("Invalid Data Or Data Not Save incatch !!", "alert-danger"));
				errors.hasErrors();
				return "user/createrequest";
			}
		}
	}

	/* ===== MAIL SERVICE ========= */
	@PostMapping("/sendingEmail")
	public MailResponse sendEmail(@RequestParam("to") String to) {
		Map<String, Object> model = new HashMap<>();
		model.put("Name", "Admin");
		model.put("location", "odisha,India");

		return service.sendRequestEmail(to, model);

	}

	/*
	 * ===== MODIFY REQUEST PROCESS=========
	 * 
	 * @PostMapping("/updaterequest") public String updateRequest(@Valid
	 * RequestEntity requestEntity, Errors errors, @RequestParam("reqid") int reqid,
	 * 
	 * @RequestParam("reqcode") String reqcode, @RequestParam("reqtitle") String
	 * reqtitle,
	 * 
	 * @RequestParam("reqdesc") String reqdesc, @RequestParam("reqdeptcode") String
	 * reqtodepart,
	 * 
	 * @RequestParam("reqassignto") int reqtoperson, @RequestParam("reqinicomment")
	 * String reqfstcomment,
	 * 
	 * @RequestParam("sestdesc") String reqstatus, HttpSession session,
	 * HttpServletResponse response) {
	 * 
	 * response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate"); if
	 * ((session.getAttribute("username") == null)) {
	 * System.out.println(session.getAttribute("username")); return
	 * "redirect:/home/index"; } else { try { long millis =
	 * System.currentTimeMillis(); java.sql.Date date = new java.sql.Date(millis);
	 * char stuscod = reqstatus.charAt(0);
	 * 
	 * if (errors.hasErrors()) { return "redirect:{reqcode}/getrequestbycode"; }
	 * else { StatusEntity se = new StatusEntity(); se.setSescode(stuscod);
	 * se.setSestdesc(reqstatus); se.setReqdate(date); se.setReqcreateby((int)
	 * session.getAttribute("uid"));
	 * 
	 * RequestEntity re = new RequestEntity(); List<StatusEntity> selist = new
	 * ArrayList<StatusEntity>(); re.setReqid(reqid);
	 * re.setReqdeptcode(reqtodepart); re.setReqcode(reqcode);
	 * re.setReqtitle(reqtitle); re.setReqdesc(reqdesc); re.setReqassigndate(date);
	 * re.setReqassignto(reqtoperson); re.setReqinicomment(reqfstcomment);
	 * re.setRecreatedby((int) session.getAttribute("uid")); selist.add(se);
	 * re.setStatusEntity(selist); se.setRequestEntity(re);
	 * 
	 * RequestEntity entity = this.requestService.updateRequest(re); if (entity !=
	 * null) { session.setAttribute("message", new
	 * Message("Request Update Successfully !! Your Request Refernece No : " +
	 * reqcode, "alert-success")); return "redirect:user/viewrequest"; } else {
	 * session.setAttribute("message", new
	 * Message("Request Update Fail !! Please try Againg ", "alert-danger")); return
	 * "redirect:{reqcode}/getrequestbycode"; } }
	 * 
	 * } catch (Exception e) { session.setAttribute("message", new
	 * Message("Invalid Data Or Data Not Save !!", "alert-danger"));
	 * errors.hasErrors(); return "redirect:{reqcode}/getrequestbycode"; }
	 * 
	 * } }
	 */

	/* ===== MODIFY REQUEST PROCESS========= */
	@PostMapping("/updaterequest")
	public String updateRequest(@Valid RequestEntity requestEntity, Errors errors, @RequestParam("reqid") int reqid,
			@RequestParam("reqcode") String reqcode, @RequestParam("reqtitle") String reqtitle,
			@RequestParam("reqdesc") String reqdesc, @RequestParam("reqdeptcode") String reqtodepart,
			@RequestParam("reqassignto") int reqtoperson, @RequestParam("reqinicomment") String reqfstcomment,
			@RequestParam("sestdesc") String reqstatus, HttpSession session, HttpServletResponse response) {

		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				long millis = System.currentTimeMillis();
				java.sql.Date date = new java.sql.Date(millis);
				char stuscod = reqstatus.charAt(0);

				if (errors.hasErrors()) {
					return "redirect:{reqcode}/getrequestbycode";
				} else {
					
					
					
					System.out.println(session.getAttribute("assigndate"));
					
					CommentsEntity ce = new CommentsEntity();
					ce.setCmdesc(reqfstcomment);
					ce.setCmreqdate(date);
					ce.setCmreqcreateby((int) session.getAttribute("uid"));
					System.out.println();

					System.out.println("_===============" + ce);
					System.out.println();
					StatusEntity se = new StatusEntity();
					se.setSescode(stuscod);
					se.setSestdesc(reqstatus);
					se.setReqdate(date);
					se.setReqcreateby((int) session.getAttribute("uid"));

					System.out.println();
					System.out.println("_===============" + se.toString());
					System.out.println();

					RequestEntity re = new RequestEntity();
					List<StatusEntity> selist = new ArrayList<StatusEntity>();
					List<CommentsEntity> celist = new ArrayList<CommentsEntity>();

					re.setReqid(reqid);
					re.setReqdeptcode(reqtodepart);
					System.out.println(reqcode);
					re.setReqcode(reqcode);
					re.setReqtitle(reqtitle);
					re.setReqdesc(reqdesc);
					re.setReqassigndate((Date) session.getAttribute("assigndate"));
					re.setReqassignto(reqtoperson);
					re.setReqinicomment((String) session.getAttribute("reqinicomment1"));
					re.setRecreatedby((int) session.getAttribute("uid"));
					selist.add(se);
					celist.add(ce);
					re.setStatusEntity(selist);
					re.setcCommentsEntity(celist);
					se.setRequestEntity(re);
					ce.setRequestEntity(re);
					System.out.println();
					System.out.println("_===============" + re);
					System.out.println();

					RequestEntity entity = this.requestService.updateRequest(re);
					if (entity != null) {
						session.setAttribute("message",
								new Message("Request Update Successfully !! Your Request Refernece No : " + reqcode,
										"alert-success"));
						return "redirect:user/viewrequest";
					} else {
						session.setAttribute("message",
								new Message("Request Update Fail !! Please try Againg ", "alert-danger"));
						return "redirect:{reqcode}/getrequestbycode";
					}
				}

			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				errors.hasErrors();
				return "redirect:{reqcode}/getrequestbycode";
			}

		}
	}
	/* ===== ADD COMMENT ON REQUEST========= */

	@PostMapping("/updaterequestcomment")
	public String updateRequestComment(@Valid RequestEntity requestEntity, Errors errors,
			@RequestParam("reqid") int reqid, @RequestParam("reqcode") String reqcode,
			@RequestParam("reqtitle") String reqtitle, @RequestParam("reqdesc") String reqdesc,
			@RequestParam("reqdeptcode") String reqtodepart, @RequestParam("reqassignto") int reqtoperson,
			@RequestParam("reqinicomment") String reqfstcomment, @RequestParam("sestdesc") String reqstatus,
			HttpSession session, HttpServletResponse response) {

		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				long millis = System.currentTimeMillis();
				java.sql.Date date = new java.sql.Date(millis);
				char stuscod = reqstatus.charAt(0);

				if (errors.hasErrors()) {
					return "redirect:{reqcode}/getrequestbycode";
				} else {
					System.out.println(session.getAttribute("reqinicomment1"));
					System.out.println(session.getAttribute("assigndate"));

					CommentsEntity ce = new CommentsEntity();
					ce.setCmdesc(reqfstcomment);
					ce.setCmreqdate(date);
					ce.setCmreqcreateby((int) session.getAttribute("uid"));
					System.out.println();

					System.out.println("_===============" + ce);
					System.out.println();

					StatusEntity se = new StatusEntity();
					se.setSescode(stuscod);
					se.setSestdesc(reqstatus);
					se.setReqdate(date);
					se.setReqcreateby((int) session.getAttribute("uid"));

					System.out.println();
					System.out.println("_===============" + se.toString());
					System.out.println();

					RequestEntity re = new RequestEntity();
					List<StatusEntity> selist = new ArrayList<StatusEntity>();
					List<CommentsEntity> celist = new ArrayList<CommentsEntity>();

					re.setReqid(reqid);
					re.setReqdeptcode(reqtodepart);
					System.out.println(reqcode);

					re.setReqcode(reqcode);
					re.setReqtitle(reqtitle);
					re.setReqdesc(reqdesc);
					re.setReqassigndate((Date) session.getAttribute("assigndate"));
					re.setReqassignto(reqtoperson);
					re.setReqinicomment((String) session.getAttribute("reqinicomment1"));
					re.setRecreatedby((int) session.getAttribute("uid"));
					selist.add(se);
					celist.add(ce);
					re.setStatusEntity(selist);
					re.setcCommentsEntity(celist);
					se.setRequestEntity(re);
					ce.setRequestEntity(re);
					System.out.println();
					System.out.println("_===============" + re);
					System.out.println();

					RequestEntity entity = this.requestService.updateRequest(re);
					System.out.println(entity);
					if (entity != null) {
						session.setAttribute("message",
								new Message("Comment added Successfully !! Your Request Refernece No : " + reqcode,
										"alert-success"));
						return "redirect:user/viewrequest";
					} else {
						session.setAttribute("message",
								new Message("Comment Fail !! Please try Againg ", "alert-danger"));
						return "redirect:{reqcode}/getrequestbycode";
					}
				}

			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				errors.hasErrors();
				return "redirect:{reqcode}/getrequestbycode";
			}

		}
	}

	/* ===== Save New User PROCESS ===== */
	@RequestMapping("/savenewuserprocess")
	public String savenewuser(@Valid @ModelAttribute("userEntity") UserEntity userEntity, Errors errors,
			HttpSession session, HttpServletResponse response) {
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				if (errors.hasErrors()) {
					return "user/createuser";
				} else {
					long millis = System.currentTimeMillis();
					java.sql.Date date = new java.sql.Date(millis);
					Boolean userstatus = Boolean.valueOf(userEntity.isuIsActive());

					userEntity.setuCDate(date);
					userEntity.setuCBy((String) session.getAttribute("username"));
					userEntity.setuIsActive(userstatus);
					System.out.println(userEntity);
					UserEntity isUserSave = this.userService.CreateNewUser(userEntity);
					if (isUserSave != null) {
						session.setAttribute("message",
								new Message("User Create Successfully !! New Username is  :  " + isUserSave.getuName(),
										"alert-success"));
						return "redirect:user/createdepartment";
					} else {
						session.setAttribute("message",
								new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
						return "user/createuser";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				System.out.println("ssdsd1");
				errors.hasErrors();
				return "user/createuser";
			}
		}
	}

	/* ======== Save list of Department user role ======== */
	@PostMapping(path = "/saveuserrole")
	public String SaveUserDeptRole(@RequestBody List<UserDeptEntity> userDeptEntity,HttpSession session, HttpServletResponse response) {

		String res = null;
		System.out.println(userDeptEntity);
		if (userDeptEntity != null) {
			UserDeptEntity entity = this.userDeptService.saveUserDeptAccess(userDeptEntity);
			System.out.println("000000000000000000000");
			
			if (entity != null) {
				System.out.println("1111111111111111111111");
				session.setAttribute("message",
						new Message("User Role Successfully Save !! :  " + entity.getUserid() ,
								"alert-success"));
				return "redirect:user/createdepartment";
			} else {
				System.out.println("22222222222222222222222222");

				session.setAttribute("message",
						new Message("User Role in not Save !! :  " ,
								"alert-danger"));
				return "redirect:user/createdepartment";
			}
		}
		System.out.println("3333333333333333333");

		return "redirect:user/createdepartment";
	}

	/* ======== Update user date PROCESS ======== */
	@PostMapping(path = "/saveusersprocess")
	public String updateUser() {
		return null;
	}

}