package com.crts.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "status_entity")
public class StatusEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "status_id")
	private int seid;

	@Column(name = "status_code")
	private char sescode;

	@Column(length = 25, name = "status_desc")
	private String sestdesc;

	@Column(name = "created_date")
	private Date reqdate;

	@Column(name = "created_by")
	private int reqcreateby;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "request_number")
	@JsonBackReference
	private RequestEntity requestEntity;

	public int getSeid() {
		return seid;
	}

	public void setSeid(int seid) {
		this.seid = seid;
	}

	public char getSescode() {
		return sescode;
	}

	public void setSescode(char sescode) {
		this.sescode = sescode;
	}

	public String getSestdesc() {
		return sestdesc;
	}

	public void setSestdesc(String sestdesc) {
		this.sestdesc = sestdesc;
	}

	public Date getReqdate() {
		return reqdate;
	}

	public void setReqdate(Date reqdate) {
		this.reqdate = reqdate;
	}

	public int getReqcreateby() {
		return reqcreateby;
	}

	public void setReqcreateby(int reqcreateby) {
		this.reqcreateby = reqcreateby;
	}

	public RequestEntity getRequestEntity() {
		return requestEntity;
	}

	public void setRequestEntity(RequestEntity requestEntity) {
		this.requestEntity = requestEntity;
	}

	
	public StatusEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "StatusEntity [seid=" + seid + ", sescode=" + sescode + ", sestdesc=" + sestdesc + ", reqdate=" + reqdate
				+ ", reqcreateby=" + reqcreateby + ", requestEntity=" + requestEntity + "]";
	}

	public StatusEntity(String sestdesc, Date reqdate, RequestEntity requestEntity) {
		super();
		this.sestdesc = sestdesc;
		this.reqdate = reqdate;
		this.requestEntity = requestEntity;
	}




	
	
	
	
	
}
