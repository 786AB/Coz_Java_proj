package com.crts.dto;

import java.util.List;

import com.crts.entity.UserDeptEntity;

public class UserDeptDTO {

	private List<UserDeptEntity> userDeptEntity;

	public void addUserDept(UserDeptEntity userDeptEntity) {
		this.userDeptEntity.add(userDeptEntity);
	}

	public List<UserDeptEntity> getUserDeptEntity() {
		return userDeptEntity;
	}

	public void setUserDeptEntity(List<UserDeptEntity> userDeptEntity) {
		this.userDeptEntity = userDeptEntity;
	}

	public UserDeptDTO(List<UserDeptEntity> userDeptEntity) {
		super();
		this.userDeptEntity = userDeptEntity;
	}

	public UserDeptDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UserDeptDTO [userDeptEntity=" + userDeptEntity + "]";
	}

	
	
	
	
	
	
	
	


}
