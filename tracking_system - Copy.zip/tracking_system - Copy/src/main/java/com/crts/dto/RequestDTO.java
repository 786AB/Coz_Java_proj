package com.crts.dto;

import com.crts.entity.RequestEntity;

public class RequestDTO {
	
	
	private RequestEntity requestEntity;
	private String message;
	public RequestEntity getRequestEntity() {
		return requestEntity;
	}
	public String getMessage() {
		return message;
	}
	public void setRequestEntity(RequestEntity requestEntity) {
		this.requestEntity = requestEntity;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	
	
	
	
	

}
