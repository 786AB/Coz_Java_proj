package com.crts.service;


import org.springframework.stereotype.Service;
import com.crts.entity.RequestEntity;

@Service
public interface RequestService {

	/* ======== Generate Request Code ======== */
	public String getLastRequestNumberByDeptId(String deptcode);
	
	
	/* ======== Save Request ======== */
	public boolean saveRequest(String reqtitle,String reqdesc, String reqtodepart, String getNewRequestNum,
			String reqtoperson,String reqfstcomment,String reqstatus);

	
	/* ======== Get Request By Request Code ======== */
	public RequestEntity getRequestByReqcode(String rcode);

	/* ======== Update Request ======== */
	public RequestEntity updateRequest(RequestEntity re);

}
