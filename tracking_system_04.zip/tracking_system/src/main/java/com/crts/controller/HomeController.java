package com.crts.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.crts.entity.DeptEntity;
import com.crts.entity.MailResponse;
import com.crts.entity.RequestEntity;
import com.crts.entity.StatusEntity;
import com.crts.entity.UserEntity;
import com.crts.helper.Message;
import com.crts.service.DeptService;
import com.crts.service.RequestService;
import com.crts.service.StatusService;
import com.crts.service.UserService;
import com.crts.serviceimpl.EmailService;

@Controller
@RequestMapping("/home")
@CrossOrigin("*")
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private DeptService deptService;

	@Autowired
	private RequestService requestService;

	@Autowired
	private StatusService statusService;

	
	@Autowired
	private EmailService service;
	

	
	
	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/")
	public String welcome(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult, Model model,
			HttpSession session, HttpServletResponse response) {
		session.invalidate();
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		System.out.println("32");
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	/* ===== LOGIN PAGE OR WELCOME PAGE ========= */
	@RequestMapping("/index")
	public String welcomepage(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		System.out.println("334");
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		session.invalidate();
		model.addAttribute("title", "Login - Request Tracking System");
		return "index";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		session.setAttribute("message", new Message("Successfully Logout!!", "alert-danger"));
		session.invalidate();
		return "redirect:/home/index";
	}

	/* ===== HOME PAGE ========= */
	@RequestMapping("user/dashboard")
	public String home(Model model, HttpSession session, HttpServletResponse response) {

		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			List<StatusEntity> allstatus = this.statusService.getAllStatus();
			model.addAttribute("title", "Home - Request Tracking System");
			model.addAttribute("allstatus", allstatus);
			return "user/user_dashboard";
		}
	}

	/* ===== UPDATE PASSWORD PAGE ========= */
	@RequestMapping("user/updatepassword")
	public String validuserfrom(@ModelAttribute("userEntity") UserEntity userEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Update Password - Request Tracking System");
			return "user/updatepassword";
		}
	}

	/* ===== DEPARTMENT PAGE ========= */
	@RequestMapping("user/createdepartment")
	public String createdepartment(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Add Department - Request Tracking System");
			List<String> ParentCodeList = this.deptService.getAllParentDeptCode();
			model.addAttribute("ParentCodeList", ParentCodeList);
			return "user/createdepartment";
		}
	}

	/* ===== ADDREQUEST PAGE ========= */
	@RequestMapping("user/createrequest")
	public String addrequestpage(@ModelAttribute("requestEntity") RequestEntity requestEntity,
			BindingResult bindingResult, Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			List<String> deptCodeList = this.deptService.getAllDeptCode();
			model.addAttribute("deptCodeList", deptCodeList);
			model.addAttribute("title", "Add Request - Request Tracking System");
			return "user/createrequest";
		}
	}

	/* ===== MODIFY REQUEST PAGE ========= */
	@GetMapping("{rcode}/getrequestbycode")
	public String GetRequestByreqcode(@PathVariable("rcode") String rcode,
			@ModelAttribute("requestEntity") RequestEntity requestEntity, BindingResult bindingResult, Model model,
			HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			RequestEntity getReuestEntity = this.requestService.getRequestByReqcode(rcode);
			model.addAttribute("requestEntity", getReuestEntity);
			List<String> ParentCodeList = this.deptService.getAllParentDeptCode();
			model.addAttribute("ParentCodeList", ParentCodeList);
			return "user/editrequest";
		}
	}

	
	
	
	
	
	@RequestMapping("user/createuser")
	public String createuser(@ModelAttribute("deptEntity") DeptEntity deptEntity, BindingResult bindingResult,
			Model model, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			model.addAttribute("title", "Add User - Request Tracking System");
			return "user/createuser";
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/* ===== lOGIN USER BY USER NAME AND PASSWORD PROCESS ========= */
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public String checklogin(@Valid UserEntity userEntity, BindingResult bindingResult, Model model, Errors errors,
			@RequestParam("uName") String username, @RequestParam("uPassword") String password, HttpSession session,
			HttpServletResponse response) {
		try {
			if (errors.hasErrors()) {
				session.setAttribute("message", new Message("Invalid UserId or Password!!", "alert-danger"));

				return "/index";
			} else {
				UserEntity isValidUser = this.userService.userValidate(username, password);
				if (isValidUser != null) {
					List<StatusEntity> allstatus = this.statusService.getAllStatus();
					model.addAttribute("title", "Home - Request Tracking System");
					model.addAttribute("allstatus", allstatus);
					session.setAttribute("isValidUser", isValidUser);
					session.setAttribute("username", isValidUser.getuFName());
					return "redirect:/home/user/dashboard";
				} else {
					session.setAttribute("message", new Message("Invalid UserId or Password!!", "alert-danger"));

					return "/index";
				}
			}
		} catch (Exception e) {
			session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));

			return "/index";
		}
	}

	/* ===== CHANGING PASSWORD PROCESS========= */
	@PostMapping("/updatepwProcess")
	public String changepw(@Valid UserEntity userEntity, BindingResult bindingResult, Errors errors,
			@RequestParam("uPassword") String password, @RequestParam("uName") String username, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				if (errors.hasErrors()) {
					return "user/updatepassword";
				} else {
					UserEntity ue = new UserEntity();
					ue = this.userService.validatingUserNameOrEmailid(username);
					if (ue != null) {
						ue.setuPassword(password);
						boolean isPasswordUpdate = this.userService.updatePassword(ue);
						if (isPasswordUpdate) {
							session.setAttribute("message", new Message("Password update !!", "alert-success"));
							return "user/updatepassword";
						} else {
							session.setAttribute("message", new Message("Invalid Email Address !!", "alert-danger"));
							return "user/updatepassword";
						}
					} else {
						errors.hasErrors();
						session.setAttribute("message", new Message("Invalid Password !!", "alert-danger"));
						return "user/updatepassword";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid UserId or Password !!", "alert-danger"));
				errors.hasErrors();
				return "user/updatepassword";
			}
		}
	}

	/* ===== Save Department PROCESS ===== */
	@PostMapping("/savedeptprocess")
	public String savedept(@Valid DeptEntity deptEntity, Errors errors, @RequestParam("decode") String dcode,
			@RequestParam("dename") String dname, @RequestParam("depcode") String dpcode,
			@RequestParam("deisactive") String diact, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				String createby = (String) session.getAttribute("username");
				System.out.println(createby);
				if (errors.hasErrors()) {
					return "user/createdepartment";
				} else {
					boolean isDepartmentSave = this.deptService.saveDepartment(dcode, dname, dpcode, createby, diact);
					if (isDepartmentSave) {
						session.setAttribute("message",	new Message("Department Save Successfully !!", "alert-success"));
						return "redirect:user/createdepartment";
					} else {
						session.setAttribute("message",	new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
						return "redirect:user/createdepartment";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				errors.hasErrors();
				return "user/createdepartment";
			}
		}
	}

	/* ===== Generate New Request PROCESS ===== */
	@PostMapping("/generaterequest")
	public String saveRequest(@Valid RequestEntity requestEntity, Errors errors,
			@RequestParam("reqtitle") String reqtitle, @RequestParam("reqdesc") String reqdesc,
			@RequestParam("reqdeptcode") String reqtodepart, @RequestParam("reqassignto") String reqtoperson,
			@RequestParam("reqinicomment") String reqfstcomment, @RequestParam("sestdesc") String reqstatus,
			HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				if (errors.hasErrors()) {
					return "user/createrequest";
				} else {
					String getNewRequestNum1 = this.requestService.getLastRequestNumberByDeptId(reqtodepart);
					String getNewRequestNum = reqtodepart + getNewRequestNum1;
					boolean isRequestSave = this.requestService.saveRequest(reqtitle, reqdesc, getNewRequestNum,
							reqtodepart, reqtoperson, reqfstcomment, reqstatus);
					if (isRequestSave) {
						session.setAttribute("message", new Message(
								"Request Generate Successfully !! Your Request Refernece No : " + getNewRequestNum,
								"alert-success"));
						Map<String, Object> model = new HashMap<>();
						model.put("Requestby", "Admin");
						model.put("reqno", getNewRequestNum);
						model.put("reqtitle", reqtitle);
						model.put("reqmessage", reqdesc);

						model.put("location", "odisha,India");
						service.sendEmail("sambit@cozentus.com", model);

						return "redirect:user/createrequest";
					} else {
						session.setAttribute("message",
								new Message("Request Generate Fail !! Please try Againg ", "alert-danger"));
						return "redirect:user/createrequest";
					}
				}
			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				errors.hasErrors();
				return "user/createrequest";
			}
		}
	}
	
	
	/* ===== MAIL SERVICE  ========= */
	@PostMapping("/sendingEmail")
	public MailResponse sendEmail(@RequestParam("to") String to) {	
		Map<String, Object> model = new HashMap<>();
		model.put("Name", "Admin");
		model.put("location", "odisha,India");
		
		return service.sendEmail(to, model);

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/* ===== MODIFY REQUEST PROCESS========= */
	@PostMapping("/updaterequest")
	public String updateRequest(@Valid RequestEntity requestEntity, Errors errors, @RequestParam("reqid") int reqid,
			@RequestParam("reqcode") String reqcode, @RequestParam("reqtitle") String reqtitle,
			@RequestParam("reqdesc") String reqdesc, @RequestParam("reqdeptcode") String reqtodepart,
			@RequestParam("reqassignto") String reqtoperson, @RequestParam("reqinicomment") String reqfstcomment,
			@RequestParam("sestdesc") String reqstatus, HttpSession session, HttpServletResponse response) {

		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
		if ((session.getAttribute("username") == null)) {
			System.out.println(session.getAttribute("username"));
			return "redirect:/home/index";
		} else {
			try {
				long millis = System.currentTimeMillis();
				java.sql.Date date = new java.sql.Date(millis);
				char stuscod = reqstatus.charAt(0);

				if (errors.hasErrors()) {
					return "redirect:{reqcode}/getrequestbycode";
				} else {
					StatusEntity se = new StatusEntity();
					se.setSeid(stuscod);
					se.setSescode(stuscod);
					se.setSestdesc(reqstatus);
					se.setReqdate(date);
					se.setReqcreateby("a");

					RequestEntity re = new RequestEntity();
					List<StatusEntity> selist = new ArrayList<StatusEntity>();
					re.setReqid(reqid);
					re.setReqdeptcode(reqtodepart);
					re.setReqcode(reqcode);
					re.setReqtitle(reqtitle);
					re.setReqdesc(reqdesc);
					re.setReqassigndate(date);
					re.setReqassignto(reqtoperson);
					re.setReqinicomment(reqfstcomment);
					re.setReqcreateby("bb");
					selist.add(se);
					re.setStatusEntity(selist);
					se.setRequestEntity(re);
					RequestEntity entity = this.requestService.updateRequest(re);
					if (entity != null) {
						session.setAttribute("message",
								new Message("Request Update Successfully !! Your Request Refernece No : " + reqtodepart,
										"alert-success"));
						return "redirect:user/dashboard";
					} else {
						session.setAttribute("message",
								new Message("Request Update Fail !! Please try Againg ", "alert-danger"));
						return "redirect:{reqcode}/getrequestbycode";
					}
				}

			} catch (Exception e) {
				session.setAttribute("message", new Message("Invalid Data Or Data Not Save !!", "alert-danger"));
				errors.hasErrors();
				return "redirect:{reqcode}/getrequestbycode";
			}

		}
	}

}