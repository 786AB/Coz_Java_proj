package com.crts.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crts.entity.DeptEntity;
import com.crts.entity.MailRequest;
import com.crts.entity.MailResponse;
import com.crts.entity.RequestEntity;
import com.crts.entity.StatusEntity;
import com.crts.service.DeptService;
import com.crts.service.RequestService;
import com.crts.service.StatusService;
import com.crts.serviceimpl.EmailService;

@RestController
@RequestMapping("/getdata")
@CrossOrigin("*")
public class DataController {

	@Autowired
	private DeptService deptService;

	@Autowired
	private RequestService requestService;

	@Autowired
	private StatusService statusService;	
	
	/*
	 * @GetMapping("/getlastrequestnumber") public String
	 * getLastRequestNumber(@RequestParam("deptcode") String deptcode, Model model)
	 * { System.out.println(deptcode); return
	 * this.requestService.getLastRequestNumberByDeptId(deptcode); }
	 */

	@GetMapping("/getdeptuser")
	public List<DeptEntity> getDeptUserByDeptCode(@RequestParam("deptcode") String deptcode, Model model) {
		return this.deptService.getDeptUserByDeptcode(deptcode);
	}

	@GetMapping("/getalldept")
	public List<DeptEntity> getAllDept(@RequestParam("deptcode") String deptcode, Model model) {
		return this.deptService.getDeptUserByDeptcode(deptcode);
	}

	/* ======== Get Request By Request Code ======== */
	@GetMapping("/getrequestbycode")
	public RequestEntity GetRequestByreqcode(@RequestParam("rcode") String rcode) {
		RequestEntity requestByReqcode = this.requestService.getRequestByReqcode(rcode);
		return requestByReqcode;
	}

	/* ======== Get Status By Request Code ======== */
	@GetMapping("/getstatusbycode")
	public StatusEntity GetStatusByreqcode(@RequestParam("rcode") int rcode) {
		StatusEntity statusByReqcode = this.statusService.getStatusByRequestNumber(rcode);
		return statusByReqcode;
	}

}
