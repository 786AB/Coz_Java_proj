package com.crts.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crts.entity.RequestEntity;

@Repository
public interface RequestRepo extends JpaRepository<RequestEntity, Integer> {

	/* ======== Get Last Request Code ======== */
	@Query("select max(re.reqcode) from RequestEntity re where re.reqdeptcode = :deptcode")
	public String getLastRequestNumber(@Param("deptcode") String deptcode);
	
	/* ======== Get Request By Request Code ======== */
	public 	RequestEntity getByreqcode(String reqcode);
	
	

}
